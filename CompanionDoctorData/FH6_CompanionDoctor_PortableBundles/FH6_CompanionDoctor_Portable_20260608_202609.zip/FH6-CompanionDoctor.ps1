<#
FH6 Companion Doctor v4.0

External Forza Horizon 6 companion, diagnostics, save/cache manager, crash lab,
telemetry listener, device doctor, launcher, and support-package builder.

Safety model:
  - Never modifies the Steam game install or forzahorizon6.exe.
  - Never injects into the game, reads game memory, automates gameplay, or edits saves.
  - Cleanup operations are limited to FH6 user/save/cache/crash-report roots.
  - Backup is enabled by default for destructive actions.
  - Telemetry uses FH6's official one-way "Data Out" UDP feature.

Run:
  powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "$env:USERPROFILE\Downloads\FH6-CompanionDoctor.ps1"
#>

[CmdletBinding()]
param(
    [switch]$NoGui,
    [switch]$Snapshot,
    [switch]$Diff,
    [switch]$SelfTest,
    [switch]$Manifest,
    [switch]$PortableBundle
)

$ErrorActionPreference = 'Stop'

$script:Config = [ordered]@{
    AppId        = '2483190'
    GameName     = 'Forza Horizon 6'
    ExeName      = 'forzahorizon6.exe'
    LocalRoot    = Join-Path $env:LOCALAPPDATA 'ForzaHorizon6'
    SharedRoot   = Join-Path (Join-Path $env:LOCALAPPDATA 'ForzaHorizon6') 'LocalStorage_Shared'
    XboxPgsRoot  = Join-Path $env:SystemDrive 'XboxGames\GameSave\pgs'
    Downloads    = Join-Path $env:USERPROFILE 'Downloads'
    BackupRoot   = Join-Path (Join-Path $env:USERPROFILE 'Downloads') 'FH6_CompanionDoctor_Backups'
    ReportRoot   = Join-Path (Join-Path $env:USERPROFILE 'Downloads') 'FH6_CompanionDoctor_Reports'
    PackageRoot  = Join-Path (Join-Path $env:USERPROFILE 'Downloads') 'FH6_CompanionDoctor_SupportPackages'
    LogRoot      = Join-Path (Join-Path $env:USERPROFILE 'Downloads') 'FH6_CompanionDoctor_Logs'
    TelemetryRoot = Join-Path (Join-Path $env:USERPROFILE 'Downloads') 'FH6_CompanionDoctor_Telemetry'
    SnapshotRoot = Join-Path (Join-Path $env:USERPROFILE 'Downloads') 'FH6_CompanionDoctor_Snapshots'
    SessionRoot  = Join-Path (Join-Path $env:USERPROFILE 'Downloads') 'FH6_CompanionDoctor_Sessions'
    BundleRoot   = Join-Path (Join-Path $env:USERPROFILE 'Downloads') 'FH6_CompanionDoctor_PortableBundles'
    ManifestPath = Join-Path (Join-Path $env:USERPROFILE 'Downloads') 'FH6_CompanionDoctor_Manifest.json'
    SettingsPath = Join-Path (Join-Path $env:USERPROFILE 'Downloads') 'FH6_CompanionDoctor_Settings.json'
}

$script:RunLogPath = $null
$script:Items = @()
$script:ItemsById = @{}
$script:UdpClient = $null
$script:TelemetryCsvPath = $null
$script:TelemetryPacketCount = 0
$script:TelemetryLastPacket = $null
$script:MonitorActive = $false
$script:MonitorRunCount = 0
$script:MonitorLastAction = 'Idle'
$script:SessionActive = $false
$script:SessionId = $null
$script:SessionStart = $null
$script:SessionBeforeSnapshot = $null
$script:SessionSeenProcess = $false

function New-ToolDirectory {
    foreach ($path in @($script:Config.BackupRoot, $script:Config.ReportRoot, $script:Config.PackageRoot, $script:Config.LogRoot, $script:Config.TelemetryRoot, $script:Config.SnapshotRoot, $script:Config.SessionRoot, $script:Config.BundleRoot)) {
        New-Item -ItemType Directory -Path $path -Force | Out-Null
    }
}

function Get-DefaultSettings {
    [pscustomobject]@{
        TelemetryPort     = 5606
        TelemetryCsv      = $true
        BackupByDefault   = $true
        DryRunByDefault   = $false
        StopGameByDefault = $false
        MonitorMode       = 'Saves only'
        MonitorSeconds    = 30
        CorrelationMinutes = 10
        LastTab           = 'Health'
    }
}

function Read-CompanionSettings {
    $defaults = Get-DefaultSettings
    if (-not (Test-Path -LiteralPath $script:Config.SettingsPath)) { return $defaults }
    try {
        $loaded = Get-Content -LiteralPath $script:Config.SettingsPath -Raw | ConvertFrom-Json
        foreach ($prop in $defaults.PSObject.Properties.Name) {
            if ($null -eq $loaded.$prop) { $loaded | Add-Member -NotePropertyName $prop -NotePropertyValue $defaults.$prop }
        }
        return $loaded
    }
    catch {
        return $defaults
    }
}

function Write-CompanionSettings {
    param([Parameter(Mandatory)][object]$Settings)
    New-ToolDirectory
    $Settings | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $script:Config.SettingsPath -Encoding UTF8
}

function Get-FullPathSafe {
    param([Parameter(Mandatory)][string]$Path)
    try {
        if (Test-Path -LiteralPath $Path) { return (Resolve-Path -LiteralPath $Path).Path }
        return [System.IO.Path]::GetFullPath($Path)
    }
    catch {
        return $Path
    }
}

function Test-PathUnderRoot {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Root
    )
    $full = (Get-FullPathSafe -Path $Path).TrimEnd('\')
    $rootFull = (Get-FullPathSafe -Path $Root).TrimEnd('\')
    return ($full.Equals($rootFull, [System.StringComparison]::OrdinalIgnoreCase) -or
            $full.StartsWith($rootFull + '\', [System.StringComparison]::OrdinalIgnoreCase))
}

function ConvertTo-SafeName {
    param([Parameter(Mandatory)][string]$Text)
    $safe = $Text -replace '^[A-Za-z]:\\', ''
    $safe = $safe -replace '[\\/:*?"<>|]', '_'
    $safe = $safe -replace '\s+', '_'
    if ($safe.Length -gt 160) {
        $sha = [System.Security.Cryptography.SHA256]::Create()
        $hash = ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)))).Replace('-', '').Substring(0, 12)
        $safe = $safe.Substring(0, 140) + '_' + $hash
    }
    return $safe
}

function Get-ChildStats {
    param([Parameter(Mandatory)][string]$Path)
    $item = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
    if (-not $item.PSIsContainer) {
        return [pscustomobject]@{ Items = 1; SizeBytes = [int64]$item.Length }
    }
    $count = 0
    [int64]$size = 0
    Get-ChildItem -LiteralPath $Path -Force -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
        $count++
        if (-not $_.PSIsContainer) { $size += [int64]$_.Length }
    }
    return [pscustomobject]@{ Items = $count; SizeBytes = $size }
}

function New-FH6Record {
    param(
        [Parameter(Mandatory)][string]$Category,
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Description,
        [bool]$Cleanable = $true,
        [bool]$DefaultSelected = $false,
        [string]$Risk = 'Normal'
    )
    $exists = Test-Path -LiteralPath $Path
    $stats = [pscustomobject]@{ Items = 0; SizeBytes = 0 }
    $modified = $null
    if ($exists) {
        try {
            $item = Get-Item -LiteralPath $Path -Force
            $modified = $item.LastWriteTime
            $stats = Get-ChildStats -Path $Path
        }
        catch {
            $Risk = 'Read warning'
        }
    }
    [pscustomobject]@{
        Id              = [guid]::NewGuid().ToString('N')
        Category        = $Category
        Path            = $Path
        Exists          = $exists
        Items           = $stats.Items
        SizeBytes       = $stats.SizeBytes
        SizeMB          = [math]::Round(($stats.SizeBytes / 1MB), 2)
        LastWriteTime   = $modified
        Description     = $Description
        Cleanable       = $Cleanable
        DefaultSelected = $DefaultSelected
        Risk            = $Risk
    }
}

function Get-SteamLibraries {
    $steamRoots = @(
        (Join-Path ${env:ProgramFiles(x86)} 'Steam'),
        (Join-Path $env:ProgramFiles 'Steam')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique

    $libraries = New-Object System.Collections.Generic.List[string]
    foreach ($root in $steamRoots) {
        if (-not $libraries.Contains($root)) { [void]$libraries.Add($root) }
        $libraryFile = Join-Path (Join-Path $root 'steamapps') 'libraryfolders.vdf'
        if (Test-Path -LiteralPath $libraryFile) {
            $raw = Get-Content -LiteralPath $libraryFile -Raw -ErrorAction SilentlyContinue
            if ($raw) {
                [regex]::Matches($raw, '"path"\s+"([^"]+)"') | ForEach-Object {
                    $path = $_.Groups[1].Value -replace '\\\\', '\'
                    if ((Test-Path -LiteralPath $path) -and -not $libraries.Contains($path)) {
                        [void]$libraries.Add($path)
                    }
                }
            }
        }
    }
    return $libraries.ToArray()
}

function Get-SteamInstallInfo {
    $found = New-Object System.Collections.Generic.List[object]
    foreach ($library in Get-SteamLibraries) {
        $manifest = Join-Path (Join-Path $library 'steamapps') "appmanifest_$($script:Config.AppId).acf"
        if (-not (Test-Path -LiteralPath $manifest)) { continue }
        $raw = Get-Content -LiteralPath $manifest -Raw -ErrorAction SilentlyContinue
        $installDir = 'ForzaHorizon6'
        $name = $script:Config.GameName
        $stateFlags = ''
        $lastUpdated = ''
        $sizeOnDisk = ''
        if ($raw -match '"installdir"\s+"([^"]+)"') { $installDir = $Matches[1] }
        if ($raw -match '"name"\s+"([^"]+)"') { $name = $Matches[1] }
        if ($raw -match '"StateFlags"\s+"([^"]+)"') { $stateFlags = $Matches[1] }
        if ($raw -match '"LastUpdated"\s+"([^"]+)"') { $lastUpdated = $Matches[1] }
        if ($raw -match '"SizeOnDisk"\s+"([^"]+)"') { $sizeOnDisk = $Matches[1] }
        $gameDir = Join-Path (Join-Path $library 'steamapps\common') $installDir
        $exe = Join-Path $gameDir $script:Config.ExeName
        [void]$found.Add([pscustomobject]@{
            Library       = $library
            LibraryLength = $library.Length
            Manifest      = $manifest
            Name          = $name
            InstallDir    = $gameDir
            Exe           = $exe
            ExeExists     = Test-Path -LiteralPath $exe
            StateFlags    = $stateFlags
            LastUpdated   = $lastUpdated
            SizeOnDisk    = $sizeOnDisk
        })
    }
    return $found.ToArray()
}

function Get-SteamUserDataTargets {
    $records = New-Object System.Collections.Generic.List[object]
    foreach ($library in Get-SteamLibraries) {
        $userdata = Join-Path $library 'userdata'
        if (-not (Test-Path -LiteralPath $userdata)) { continue }
        Get-ChildItem -LiteralPath $userdata -Force -Directory -ErrorAction SilentlyContinue | ForEach-Object {
            $appFolder = Join-Path $_.FullName $script:Config.AppId
            if (Test-Path -LiteralPath $appFolder) {
                [void]$records.Add((New-FH6Record -Category 'Save' -Path $appFolder -Description 'Steam userdata/cloud metadata for FH6 app ID 2483190.' -Cleanable $true -DefaultSelected $true -Risk 'Cloud'))
            }
        }
    }
    return $records.ToArray()
}

function Get-SteamLogRows {
    $rows = New-Object System.Collections.Generic.List[object]
    $patterns = @($script:Config.AppId, 'ForzaHorizon6', 'Forza Horizon 6', 'cloud', 'sync')
    foreach ($library in Get-SteamLibraries) {
        $logRoot = Join-Path $library 'logs'
        if (-not (Test-Path -LiteralPath $logRoot)) { continue }
        Get-ChildItem -LiteralPath $logRoot -Force -File -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -match 'cloud|content|appinfo|shader|bootstrap|client'
        } | ForEach-Object {
            $file = $_
            try {
                $matches = Select-String -LiteralPath $file.FullName -Pattern $patterns -SimpleMatch -ErrorAction SilentlyContinue |
                    Select-Object -Last 80
                foreach ($m in $matches) {
                    [void]$rows.Add([pscustomobject]@{
                        File       = $file.Name
                        LineNumber = $m.LineNumber
                        Text       = $m.Line.Trim()
                        Path       = $file.FullName
                    })
                }
            }
            catch {}
        }
    }
    return $rows.ToArray()
}

function Get-SteamLogSummary {
    $rows = @(Get-SteamLogRows)
    if ($rows.Count -eq 0) { return 'No recent FH6/appID/cloud entries found in Steam logs.' }
    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add("Steam log matches: $($rows.Count)")
    foreach ($r in $rows | Select-Object -Last 20) {
        [void]$lines.Add("  $($r.File):$($r.LineNumber) $($r.Text)")
    }
    return ($lines -join [Environment]::NewLine)
}

function Get-FH6Process {
    Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -match '^(forzahorizon6|ForzaHorizon6)$' }
}

function Get-GamingServicesVersion {
    try {
        $pkg = Get-AppxPackage Microsoft.GamingServices -ErrorAction Stop
        if ($pkg) { return $pkg.Version.ToString() }
    }
    catch {
        return "Unavailable: $($_.Exception.Message)"
    }
    return 'Not found'
}

function Get-XboxServiceRows {
    $serviceNames = @(
        'GamingServices',
        'GamingServicesNet',
        'XblAuthManager',
        'XblGameSave',
        'XboxGipSvc',
        'XboxNetApiSvc',
        'InstallService',
        'ClipSVC',
        'TokenBroker'
    )
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($name in $serviceNames) {
        try {
            $svc = Get-Service -Name $name -ErrorAction Stop
            [void]$rows.Add([pscustomobject]@{
                Name        = $svc.Name
                DisplayName = $svc.DisplayName
                Status      = $svc.Status.ToString()
                StartType   = $svc.StartType.ToString()
            })
        }
        catch {
            [void]$rows.Add([pscustomobject]@{
                Name        = $name
                DisplayName = ''
                Status      = 'Not found'
                StartType   = ''
            })
        }
    }
    return $rows.ToArray()
}

function Get-VisualCRedistRows {
    $roots = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($root in $roots) {
        Get-ItemProperty -Path $root -ErrorAction SilentlyContinue | Where-Object {
            $_.DisplayName -match 'Microsoft Visual C\+\+.*Redistributable'
        } | ForEach-Object {
            [void]$rows.Add([pscustomobject]@{
                Name        = $_.DisplayName
                Version     = $_.DisplayVersion
                Publisher   = $_.Publisher
                InstallDate = $_.InstallDate
            })
        }
    }
    return @($rows | Sort-Object Name, Version -Unique)
}

function Get-MediaFoundationStatus {
    $system32 = Join-Path $env:WINDIR 'System32'
    $files = @('mfplat.dll', 'mf.dll', 'mfreadwrite.dll') | ForEach-Object {
        $path = Join-Path $system32 $_
        [pscustomobject]@{
            File   = $_
            Path   = $path
            Exists = Test-Path -LiteralPath $path
        }
    }
    $missing = @($files | Where-Object { -not $_.Exists })
    [pscustomobject]@{
        Status  = if ($missing.Count -eq 0) { 'OK' } else { 'Warn' }
        Detail  = if ($missing.Count -eq 0) { 'Media Foundation DLLs present.' } else { 'Missing: ' + (($missing | Select-Object -ExpandProperty File) -join ', ') }
        Files   = $files
    }
}

function Get-WERReportRows {
    $roots = @(
        (Join-Path $env:PROGRAMDATA 'Microsoft\Windows\WER\ReportArchive'),
        (Join-Path $env:PROGRAMDATA 'Microsoft\Windows\WER\ReportQueue')
    )
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($root in $roots) {
        if (-not (Test-Path -LiteralPath $root)) { continue }
        Get-ChildItem -LiteralPath $root -Force -Directory -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -match 'forzahorizon6|ForzaHorizon6|AppCrash_forzahorizon6'
        } | Sort-Object LastWriteTime -Descending | Select-Object -First 40 | ForEach-Object {
            $wer = Join-Path $_.FullName 'Report.wer'
            $eventType = ''
            $bucket = ''
            if (Test-Path -LiteralPath $wer -ErrorAction SilentlyContinue) {
                try {
                    $content = Get-Content -LiteralPath $wer -ErrorAction SilentlyContinue
                    $eventType = (($content | Where-Object { $_ -match '^EventType=' } | Select-Object -First 1) -replace '^EventType=', '')
                    $bucket = (($content | Where-Object { $_ -match '^Bucket=' } | Select-Object -First 1) -replace '^Bucket=', '')
                }
                catch {}
            }
            [void]$rows.Add([pscustomobject]@{
                Root          = $root
                Name          = $_.Name
                LastWriteTime = $_.LastWriteTime
                EventType     = $eventType
                Bucket        = $bucket
                Path          = $_.FullName
            })
        }
    }
    return $rows.ToArray()
}

function ConvertTo-RedactedText {
    param([AllowNull()][string]$Text)
    if ($null -eq $Text) { return '' }
    $redacted = $Text
    if ($env:USERPROFILE) {
        $redacted = $redacted.Replace($env:USERPROFILE, '%USERPROFILE%')
    }
    if ($env:USERNAME) {
        $redacted = $redacted -replace [regex]::Escape($env:USERNAME), '%USERNAME%'
    }
    return $redacted
}

function Get-StartupProgramRows {
    $rows = New-Object System.Collections.Generic.List[object]
    $registryRoots = @(
        @{ Scope = 'CurrentUser'; Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run' },
        @{ Scope = 'CurrentUser'; Path = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce' },
        @{ Scope = 'LocalMachine'; Path = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run' },
        @{ Scope = 'LocalMachine'; Path = 'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce' },
        @{ Scope = 'LocalMachine32'; Path = 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Run' }
    )
    foreach ($root in $registryRoots) {
        try {
            $props = Get-ItemProperty -LiteralPath $root.Path -ErrorAction Stop
            foreach ($prop in $props.PSObject.Properties) {
                if ($prop.Name -in @('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider')) { continue }
                [void]$rows.Add([pscustomobject]@{
                    Source  = 'Registry'
                    Scope   = $root.Scope
                    Name    = $prop.Name
                    Command = [string]$prop.Value
                    Path    = $root.Path
                })
            }
        }
        catch {}
    }

    $startupFolders = @(
        @{ Scope = 'CurrentUser'; Path = [Environment]::GetFolderPath('Startup') },
        @{ Scope = 'AllUsers'; Path = [Environment]::GetFolderPath('CommonStartup') }
    )
    foreach ($folder in $startupFolders) {
        if (-not $folder.Path -or -not (Test-Path -LiteralPath $folder.Path)) { continue }
        Get-ChildItem -LiteralPath $folder.Path -Force -ErrorAction SilentlyContinue | ForEach-Object {
            [void]$rows.Add([pscustomobject]@{
                Source  = 'Startup folder'
                Scope   = $folder.Scope
                Name    = $_.Name
                Command = $_.FullName
                Path    = $folder.Path
            })
        }
    }

    try {
        Get-ScheduledTask -ErrorAction Stop | Where-Object {
            $_.Triggers | Where-Object { $_.CimClass.CimClassName -match 'Logon|Startup' }
        } | Select-Object -First 120 | ForEach-Object {
            [void]$rows.Add([pscustomobject]@{
                Source  = 'Scheduled task'
                Scope   = $_.TaskPath
                Name    = $_.TaskName
                Command = ($_.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join '; '
                Path    = $_.TaskPath
            })
        }
    }
    catch {}

    return $rows.ToArray()
}

function Get-ProcessMitigationRows {
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        $mitigation = Get-ProcessMitigation -Name $script:Config.ExeName -ErrorAction Stop
        foreach ($area in $mitigation.PSObject.Properties) {
            if ($null -eq $area.Value -or $area.MemberType -notin @('Property','NoteProperty')) { continue }
            foreach ($prop in $area.Value.PSObject.Properties) {
                [void]$rows.Add([pscustomobject]@{
                    Scope   = 'Image'
                    Area    = $area.Name
                    Setting = $prop.Name
                    Value   = [string]$prop.Value
                })
            }
        }
    }
    catch {
        [void]$rows.Add([pscustomobject]@{
            Scope   = 'Image'
            Area    = 'Unavailable'
            Setting = $script:Config.ExeName
            Value   = $_.Exception.Message
        })
    }

    try {
        $system = Get-ProcessMitigation -System -ErrorAction Stop
        foreach ($area in $system.PSObject.Properties) {
            if ($null -eq $area.Value -or $area.MemberType -notin @('Property','NoteProperty')) { continue }
            foreach ($prop in $area.Value.PSObject.Properties) {
                [void]$rows.Add([pscustomobject]@{
                    Scope   = 'System'
                    Area    = $area.Name
                    Setting = $prop.Name
                    Value   = [string]$prop.Value
                })
            }
        }
    }
    catch {}

    return $rows.ToArray()
}

function Get-ConflictProcesses {
    $patterns = @(
        'Afterburner', 'RTSS', 'Riva', 'Discord', 'obs', 'Logitech', 'lghub',
        'Nahimic', 'Sonic', 'Wallpaper', 'WeMod', 'Windhawk', 'XSplit',
        'EVGAPrecision', 'A-Volute', 'SteelSeries', 'Overwolf', 'GameBar',
        'PresentMon', 'SpecialK', 'ReShade', 'Medal', 'Outplayed',
        'Interceptor', 'Interception', 'MacType', 'Warsaw'
    )
    $regex = ($patterns | ForEach-Object { [regex]::Escape($_) }) -join '|'
    @(Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -match $regex -or $_.Path -match $regex
    } | Select-Object ProcessName, Id, Path | Sort-Object ProcessName, Id)
}

function Get-ConflictSummary {
    $hits = @(Get-ConflictProcesses)
    if ($hits.Count -eq 0) { return 'No common overlay/hook/conflict processes found.' }
    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add("$($hits.Count) possible overlay/hook/conflict process(es) found:")
    foreach ($hit in $hits) {
        [void]$lines.Add("  $($hit.ProcessName) pid=$($hit.Id) $($hit.Path)")
    }
    return ($lines -join [Environment]::NewLine)
}

function Get-AllowedRoots {
    $roots = New-Object System.Collections.Generic.List[string]
    if ($script:Config.LocalRoot) { [void]$roots.Add($script:Config.LocalRoot) }
    if ($script:Config.XboxPgsRoot) { [void]$roots.Add($script:Config.XboxPgsRoot) }
    foreach ($library in Get-SteamLibraries) {
        $userdata = Join-Path $library 'userdata'
        if (Test-Path -LiteralPath $userdata) { [void]$roots.Add($userdata) }
    }
    return $roots.ToArray()
}

function Assert-FH6SafeTarget {
    param([Parameter(Mandatory)][object]$Record)
    if (-not $Record.Cleanable) { throw "Refusing to modify non-cleanable item: $($Record.Path)" }
    if (-not (Test-Path -LiteralPath $Record.Path)) { return }

    $full = Get-FullPathSafe -Path $Record.Path
    if ($full -match '\\steamapps\\common\\ForzaHorizon6(\\|$)' -or $full -match '\\forzahorizon6\.exe$') {
        throw "Refusing to modify game install path: $full"
    }
    if ($full -match '^[A-Za-z]:\\?$') { throw "Refusing to modify drive root: $full" }
    if ($full.Equals((Get-FullPathSafe -Path $env:USERPROFILE), [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to modify user profile root: $full"
    }

    $allowed = $false
    foreach ($root in Get-AllowedRoots) {
        if (Test-PathUnderRoot -Path $full -Root $root) { $allowed = $true; break }
    }
    if (-not $allowed) { throw "Refusing to modify item outside known FH6 user/cache roots: $full" }
}

function Get-FH6Inventory {
    $records = New-Object System.Collections.Generic.List[object]

    if (Test-Path -LiteralPath $script:Config.SharedRoot) {
        Get-ChildItem -LiteralPath $script:Config.SharedRoot -Force -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -match '^User_' -or $_.Name -eq 'ForzaUserConfigSelections' -or $_.Name -match '^InputTranslationManager_'
        } | ForEach-Object {
            [void]$records.Add((New-FH6Record -Category 'Save' -Path $_.FullName -Description 'FH6 AppData account/profile save or user-setting container.' -Cleanable $true -DefaultSelected $true -Risk 'Save'))
        }
    }

    if (Test-Path -LiteralPath $script:Config.XboxPgsRoot) {
        Get-ChildItem -LiteralPath $script:Config.XboxPgsRoot -Force -Directory -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -match '^u_.+_16D460$'
        } | ForEach-Object {
            [void]$records.Add((New-FH6Record -Category 'Save' -Path $_.FullName -Description 'Xbox Gaming Services FH6 account save container: profile, liveries, tunes, photos, garage/estate data, and save version.' -Cleanable $true -DefaultSelected $true -Risk 'Save'))
        }
    }

    foreach ($r in Get-SteamUserDataTargets) { [void]$records.Add($r) }

    $cacheTargets = @(
        @{ Path = Join-Path $script:Config.LocalRoot 'CmsCache'; Description = 'FH6 content-management cache.' },
        @{ Path = Join-Path $script:Config.LocalRoot 'LocalStorage_Cache'; Description = 'FH6 local cache and thumbnails.' },
        @{ Path = Join-Path $script:Config.LocalRoot 'fullscreen_choice'; Description = 'FH6 fullscreen/display startup choice.' },
        @{ Path = Join-Path $script:Config.LocalRoot 'LastLaunch.timestamp'; Description = 'FH6 last launch marker.' },
        @{ Path = Join-Path $script:Config.LocalRoot 'NarratorCachedSetting'; Description = 'Cached accessibility startup setting.' }
    )
    foreach ($target in $cacheTargets) {
        if (Test-Path -LiteralPath $target.Path) {
            [void]$records.Add((New-FH6Record -Category 'Cache/Settings' -Path $target.Path -Description $target.Description -Cleanable $true -DefaultSelected $false -Risk 'Low'))
        }
    }

    if (Test-Path -LiteralPath $script:Config.LocalRoot) {
        Get-ChildItem -LiteralPath $script:Config.LocalRoot -Force -Directory -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -match '^report_\d{4}_\d{2}_\d{2}_'
        } | ForEach-Object {
            [void]$records.Add((New-FH6Record -Category 'Crash Report' -Path $_.FullName -Description 'Local FH6 pre-crash report folder. Useful for diagnosis, safe to clear after exporting.' -Cleanable $true -DefaultSelected $false -Risk 'Diagnostic'))
        }
    }

    foreach ($install in Get-SteamInstallInfo) {
        [void]$records.Add((New-FH6Record -Category 'Install Info' -Path $install.Exe -Description "Steam install detected. This tool will not modify game files. Library: $($install.Library)" -Cleanable $false -DefaultSelected $false -Risk 'Never delete'))
    }

    return $records.ToArray()
}

function Invoke-Preflight {
    param(
        [bool]$StopGame,
        [scriptblock]$Log = { param($m) Write-Host $m }
    )
    $processes = @(Get-FH6Process)
    if ($processes.Count -eq 0) { return $true }
    if ($StopGame) {
        foreach ($p in $processes) {
            & $Log "Stopping FH6 process: $($p.ProcessName) pid=$($p.Id)"
            Stop-Process -Id $p.Id -Force -ErrorAction Stop
        }
        Start-Sleep -Seconds 1
        return $true
    }
    throw "FH6 is currently running. Close it first or enable 'Stop FH6 if running'."
}

function Backup-FH6Targets {
    param(
        [Parameter(Mandatory)][object[]]$Records,
        [scriptblock]$Log = { param($m) Write-Host $m }
    )
    $existing = @($Records | Where-Object { $_.Exists -and $_.Cleanable -and (Test-Path -LiteralPath $_.Path) })
    if ($existing.Count -eq 0) { return $null }

    New-Item -ItemType Directory -Path $script:Config.BackupRoot -Force | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $stage = Join-Path $env:TEMP "FH6_CompanionDoctor_Backup_$stamp"
    $zip = Join-Path $script:Config.BackupRoot "FH6_CompanionDoctor_Backup_$stamp.zip"
    New-Item -ItemType Directory -Path $stage -Force | Out-Null

    try {
        $manifest = @()
        foreach ($record in $existing) {
            Assert-FH6SafeTarget -Record $record
            $safeName = ConvertTo-SafeName -Text $record.Path
            $dest = Join-Path $stage $safeName
            & $Log "Backing up: $($record.Path)"
            Copy-Item -LiteralPath $record.Path -Destination $dest -Recurse -Force -ErrorAction Stop
            $manifest += [pscustomobject]@{
                Category      = $record.Category
                OriginalPath  = $record.Path
                Description   = $record.Description
                Items         = $record.Items
                SizeMB        = $record.SizeMB
                LastWriteTime = $record.LastWriteTime
            }
        }
        $manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'manifest.json') -Encoding UTF8
        $content = @(Get-ChildItem -LiteralPath $stage -Force | Select-Object -ExpandProperty FullName)
        Compress-Archive -LiteralPath $content -DestinationPath $zip -Force
        & $Log "Backup written: $zip"
        return $zip
    }
    finally {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

function Restore-FH6Backup {
    param(
        [Parameter(Mandatory)][string]$ZipPath,
        [bool]$DryRun = $false,
        [scriptblock]$Log = { param($m) Write-Host $m }
    )
    if (-not (Test-Path -LiteralPath $ZipPath)) { throw "Backup zip does not exist: $ZipPath" }
    if (-not (Test-PathUnderRoot -Path $ZipPath -Root $script:Config.BackupRoot)) {
        throw "Refusing to restore a backup outside FH6 Companion Doctor backup root: $ZipPath"
    }

    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $stage = Join-Path $env:TEMP "FH6_CompanionDoctor_Restore_$stamp"
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    try {
        Expand-Archive -LiteralPath $ZipPath -DestinationPath $stage -Force
        $manifestPath = Join-Path $stage 'manifest.json'
        if (-not (Test-Path -LiteralPath $manifestPath)) { throw 'Backup manifest.json is missing. Cannot restore safely.' }
        $manifest = @(Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json)
        foreach ($entry in $manifest) {
            $targetPath = [string]$entry.OriginalPath
            $safeName = ConvertTo-SafeName -Text $targetPath
            $source = Join-Path $stage $safeName
            if (-not (Test-Path -LiteralPath $source)) {
                & $Log "Restore source missing, skipped: $source"
                continue
            }
            Assert-FH6SafeTarget -Record ([pscustomobject]@{ Path = $targetPath; Cleanable = $true })
            $parent = Split-Path -Path $targetPath -Parent
            if (-not (Test-Path -LiteralPath $parent) -and -not $DryRun) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
            if (Test-Path -LiteralPath $targetPath) {
                $existing = Get-Item -LiteralPath $targetPath -Force
                $existingParent = if ($existing.PSIsContainer) { $existing.Parent.FullName } else { Split-Path -Path $existing.FullName -Parent }
                $moveLeaf = "$($existing.Name).pre_restore_$stamp"
                $movePath = Join-Path $existingParent $moveLeaf
                if ($DryRun) {
                    & $Log "DRY RUN rename existing before restore: $targetPath -> $movePath"
                }
                else {
                    Rename-Item -LiteralPath $targetPath -NewName $moveLeaf -ErrorAction Stop
                    & $Log "Renamed existing before restore: $targetPath -> $movePath"
                }
            }
            if ($DryRun) {
                & $Log "DRY RUN restore: $source -> $targetPath"
            }
            else {
                Copy-Item -LiteralPath $source -Destination $targetPath -Recurse -Force -ErrorAction Stop
                & $Log "Restored: $targetPath"
            }
        }
    }
    finally {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

function Rename-FH6Targets {
    param(
        [Parameter(Mandatory)][object[]]$Records,
        [bool]$DryRun = $false,
        [scriptblock]$Log = { param($m) Write-Host $m }
    )
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    foreach ($record in $Records) {
        if (-not $record.Exists -or -not (Test-Path -LiteralPath $record.Path)) {
            & $Log "Missing, skipped: $($record.Path)"
            continue
        }
        Assert-FH6SafeTarget -Record $record
        $item = Get-Item -LiteralPath $record.Path -Force
        $parent = if ($item.PSIsContainer) { $item.Parent.FullName } else { Split-Path -Path $item.FullName -Parent }
        $newLeaf = "$($item.Name).fh6companion_$stamp"
        $newPath = Join-Path $parent $newLeaf
        if ($DryRun) {
            & $Log "DRY RUN rename: $($record.Path) -> $newPath"
        }
        else {
            Rename-Item -LiteralPath $record.Path -NewName $newLeaf -ErrorAction Stop
            & $Log "Renamed: $($record.Path) -> $newPath"
        }
    }
}

function Remove-FH6Targets {
    param(
        [Parameter(Mandatory)][object[]]$Records,
        [bool]$DryRun = $false,
        [scriptblock]$Log = { param($m) Write-Host $m }
    )
    foreach ($record in $Records) {
        if (-not $record.Exists -or -not (Test-Path -LiteralPath $record.Path)) {
            & $Log "Missing, skipped: $($record.Path)"
            continue
        }
        Assert-FH6SafeTarget -Record $record
        if ($DryRun) {
            & $Log "DRY RUN delete: $($record.Path)"
        }
        else {
            Remove-Item -LiteralPath $record.Path -Recurse -Force -ErrorAction Stop
            & $Log "Deleted: $($record.Path)"
        }
    }
}

function Get-CrashReportRows {
    $rows = New-Object System.Collections.Generic.List[object]
    if (Test-Path -LiteralPath $script:Config.LocalRoot) {
        Get-ChildItem -LiteralPath $script:Config.LocalRoot -Force -Directory -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '^report_\d{4}_\d{2}_\d{2}_' } |
            Sort-Object LastWriteTime -Descending |
            ForEach-Object {
                $xmlPath = Join-Path $_.FullName 'PreCrashReport.xml'
                $build = ''; $gpu = ''; $driver = ''
                if (Test-Path -LiteralPath $xmlPath) {
                    try {
                        [xml]$xml = Get-Content -LiteralPath $xmlPath -Raw
                        $build = $xml.PreCrashReport.BUILD.Value
                        $gpu = $xml.PreCrashReport.THP_GPU0Description.Value
                        $driver = $xml.PreCrashReport.THP_GPU0Driver.Value
                    }
                    catch {}
                }
                [void]$rows.Add([pscustomobject]@{
                    Time       = $_.LastWriteTime
                    Name       = $_.Name
                    Build      = $build
                    GPU        = $gpu
                    Driver     = $driver
                    Path       = $_.FullName
                })
            }
    }
    return $rows.ToArray()
}

function Get-CrashEventRows {
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        $since = (Get-Date).AddDays(-7)
        Get-WinEvent -FilterHashtable @{ LogName = 'Application'; StartTime = $since } -ErrorAction SilentlyContinue |
            Where-Object { ($_.ProviderName -match 'Application Error|Windows Error Reporting') -and ($_.Message -match 'forzahorizon6|Forza Horizon 6') } |
            Sort-Object TimeCreated -Descending |
            Select-Object -First 40 |
            ForEach-Object {
                $message = ($_.Message -replace "`r?`n", ' ')
                $code = if ($message -match 'Exception code:\s*(0x[0-9a-fA-F]+)') { $Matches[1] } elseif ($message -match 'P8:\s*([a-zA-Z0-9]+)') { $Matches[1] } else { 'unknown' }
                $eventName = if ($message -match 'Event Name:\s*([^\s]+)') { $Matches[1] } else { $_.ProviderName }
                $module = if ($message -match 'Faulting module name:\s*([^,]+)') { $Matches[1].Trim() } else { '' }
                [void]$rows.Add([pscustomobject]@{
                    Time       = $_.TimeCreated
                    Provider   = $_.ProviderName
                    EventName  = $eventName
                    Code       = $code
                    Module     = $module
                    Message    = $message
                })
            }
    }
    catch {}
    return $rows.ToArray()
}

function Get-CrashSummary {
    $lines = New-Object System.Collections.Generic.List[string]
    $reports = @(Get-CrashReportRows)
    [void]$lines.Add("Local FH6 crash report folders: $($reports.Count)")
    foreach ($r in $reports | Select-Object -First 8) {
        [void]$lines.Add("  $($r.Name): build=$($r.Build) gpu=$($r.GPU) driver=$($r.Driver)")
    }
    $events = @(Get-CrashEventRows)
    [void]$lines.Add("Recent Windows FH6 crash events: $($events.Count)")
    foreach ($e in $events | Select-Object -First 8) {
        [void]$lines.Add("  $($e.Time): $($e.EventName) $($e.Code) module=$($e.Module)")
    }
    return ($lines -join [Environment]::NewLine)
}

function Get-CrashSignatureAnalysis {
    $events = @(Get-CrashEventRows)
    $reports = @(Get-CrashReportRows)
    $wer = @(Get-WERReportRows)
    $conflicts = @(Get-ConflictProcesses)
    $lines = New-Object System.Collections.Generic.List[string]

    [void]$lines.Add('Crash Signature Analysis')
    [void]$lines.Add('========================')
    [void]$lines.Add("Crash events analyzed: $($events.Count)")
    [void]$lines.Add("Local FH6 pre-crash reports: $($reports.Count)")
    [void]$lines.Add("WER report folders: $($wer.Count)")
    [void]$lines.Add('')

    if ($events.Count -eq 0) {
        [void]$lines.Add('No recent FH6 crash events were found in the Windows Application log.')
        return ($lines -join [Environment]::NewLine)
    }

    [void]$lines.Add('Grouped signatures:')
    $groups = $events | Group-Object EventName, Code, Module | Sort-Object Count -Descending
    foreach ($g in $groups | Select-Object -First 10) {
        [void]$lines.Add("  Count=$($g.Count) Signature=$($g.Name)")
    }
    [void]$lines.Add('')

    $latest = $events[0]
    [void]$lines.Add("Latest crash: $($latest.Time) $($latest.EventName) $($latest.Code) module=$($latest.Module)")
    if ($reports.Count -gt 0) {
        [void]$lines.Add("Latest FH6 report: $($reports[0].Name) build=$($reports[0].Build) gpu=$($reports[0].GPU) driver=$($reports[0].Driver)")
    }
    if ($wer.Count -gt 0) {
        [void]$lines.Add("Latest WER folder: $($wer[0].Name) event=$($wer[0].EventType) bucket=$($wer[0].Bucket)")
    }
    [void]$lines.Add('')

    [void]$lines.Add('Interpretation:')
    $codes = @($events | Select-Object -ExpandProperty Code -Unique)
    $names = @($events | Select-Object -ExpandProperty EventName -Unique)
    if ($codes -contains '0xc0000005' -or $codes -contains 'c0000005') {
        [void]$lines.Add('  - Repeated 0xc0000005/c0000005 access-violation style crashes usually point away from simple save corruption after a clean save wipe.')
        [void]$lines.Add('  - The highest-value next checks are overlays/hook processes, graphics drivers, Visual C++ runtimes, Media Foundation, clean boot, and support-package evidence.')
    }
    if ($names -contains 'BEX64') {
        [void]$lines.Add('  - BEX64 appears in the crash history. Treat process injection, overlays, monitoring/capture tools, and exploit-protection interactions as prime suspects.')
    }
    if ($latest.Module -eq 'unknown' -or [string]::IsNullOrWhiteSpace($latest.Module)) {
        [void]$lines.Add('  - The faulting module is unknown, which makes external process conflicts and low-level runtime/driver issues more plausible than a single named DLL failure.')
    }
    if ($conflicts.Count -gt 0) {
        [void]$lines.Add("  - Possible conflict processes currently detected: $((@($conflicts | Select-Object -ExpandProperty ProcessName -Unique)) -join ', ').")
    }
    else {
        [void]$lines.Add('  - No common conflict processes are currently detected, but a clean boot is still useful if crashes continue.')
    }
    [void]$lines.Add('')
    [void]$lines.Add('Recommended expert sequence:')
    [void]$lines.Add('  1. Build a Support Package immediately after a crash.')
    [void]$lines.Add('  2. Stop detected overlay/hook/monitoring tools and retry.')
    [void]$lines.Add('  3. Use Deep Fresh Start with Steam Cloud off, then launch once.')
    [void]$lines.Add('  4. If unchanged, run a clean boot and retry with no capture/overlay/performance tools.')
    [void]$lines.Add('  5. Reinstall/repair Visual C++ redistributables and confirm Media Foundation files are present.')
    [void]$lines.Add('  6. Use Steam Verify Integrity from Steam UI if missing/corrupt install files are suspected.')

    return ($lines -join [Environment]::NewLine)
}

function Get-EventTimelineRows {
    $rows = New-Object System.Collections.Generic.List[object]

    foreach ($e in Get-CrashEventRows) {
        [void]$rows.Add([pscustomobject]@{
            Time     = $e.Time
            Type     = 'Crash Event'
            Signal   = "$($e.EventName) $($e.Code)"
            Detail   = "Provider=$($e.Provider); Module=$($e.Module)"
            Path     = ''
        })
    }

    foreach ($r in Get-CrashReportRows) {
        [void]$rows.Add([pscustomobject]@{
            Time     = $r.Time
            Type     = 'FH6 Crash Report'
            Signal   = $r.Name
            Detail   = "Build=$($r.Build); Driver=$($r.Driver); GPU=$($r.GPU)"
            Path     = $r.Path
        })
    }

    foreach ($w in Get-WERReportRows) {
        [void]$rows.Add([pscustomobject]@{
            Time     = $w.LastWriteTime
            Type     = 'WER'
            Signal   = if ($w.EventType) { $w.EventType } else { $w.Name }
            Detail   = "Bucket=$($w.Bucket)"
            Path     = $w.Path
        })
    }

    foreach ($i in Get-FH6Inventory | Where-Object { $_.LastWriteTime }) {
        [void]$rows.Add([pscustomobject]@{
            Time     = $i.LastWriteTime
            Type     = $i.Category
            Signal   = $i.Risk
            Detail   = "$($i.SizeMB) MB; $($i.Items) item(s); $($i.Description)"
            Path     = $i.Path
        })
    }

    $steamLogPaths = @(Get-SteamLogRows | Select-Object -ExpandProperty Path -Unique)
    foreach ($path in $steamLogPaths) {
        if (Test-Path -LiteralPath $path -ErrorAction SilentlyContinue) {
            $item = Get-Item -LiteralPath $path -Force
            [void]$rows.Add([pscustomobject]@{
                Time     = $item.LastWriteTime
                Type     = 'Steam Log'
                Signal   = (Split-Path -Path $path -Leaf)
                Detail   = 'FH6/app/cloud/content match present in this log.'
                Path     = $path
            })
        }
    }

    return @($rows | Sort-Object Time -Descending)
}

function Get-EventTimelineSummary {
    $rows = @(Get-EventTimelineRows | Select-Object -First 60)
    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add('FH6 Event Timeline')
    [void]$lines.Add('==================')
    if ($rows.Count -eq 0) {
        [void]$lines.Add('No timeline rows found.')
        return ($lines -join [Environment]::NewLine)
    }
    foreach ($row in $rows) {
        $timeText = if ($row.Time) { ([datetime]$row.Time).ToUniversalTime().ToString('yyyy-MM-dd HH:mm:ssZ') } else { '' }
        [void]$lines.Add(("{0} | {1} | {2} | {3}" -f $timeText, $row.Type, $row.Signal, $row.Detail))
        if ($row.Path) { [void]$lines.Add("  $($row.Path)") }
    }
    return ($lines -join [Environment]::NewLine)
}

function Get-LatestFH6CrashTime {
    $times = @()
    $events = @(Get-CrashEventRows)
    if ($events.Count -gt 0 -and $events[0].Time) { $times += [datetime]$events[0].Time }
    $reports = @(Get-CrashReportRows)
    if ($reports.Count -gt 0 -and $reports[0].Time) { $times += [datetime]$reports[0].Time }
    $wer = @(Get-WERReportRows)
    if ($wer.Count -gt 0 -and $wer[0].LastWriteTime) { $times += [datetime]$wer[0].LastWriteTime }
    if ($times.Count -eq 0) { return $null }
    return @($times | Sort-Object -Descending | Select-Object -First 1)[0]
}

function Get-CrashCorrelationRows {
    param([int]$Minutes = 10)
    $latest = Get-LatestFH6CrashTime
    if (-not $latest) { return @() }
    $start = $latest.AddMinutes(-1 * [math]::Abs($Minutes))
    $end = $latest.AddMinutes([math]::Abs($Minutes))
    @(Get-EventTimelineRows | Where-Object {
        $_.Time -and ([datetime]$_.Time -ge $start) -and ([datetime]$_.Time -le $end)
    } | Sort-Object Time -Descending)
}

function Get-CrashCorrelationSummary {
    param([int]$Minutes = 10)
    $latest = Get-LatestFH6CrashTime
    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add('Latest Crash Correlation Window')
    [void]$lines.Add('===============================')
    if (-not $latest) {
        [void]$lines.Add('No FH6 crash time was available for correlation.')
        return ($lines -join [Environment]::NewLine)
    }
    [void]$lines.Add("Anchor: $($latest.ToString('yyyy-MM-dd HH:mm:ss'))")
    [void]$lines.Add("Window: +/- $Minutes minute(s)")
    [void]$lines.Add('')
    $rows = @(Get-CrashCorrelationRows -Minutes $Minutes)
    if ($rows.Count -eq 0) {
        [void]$lines.Add('No timeline rows fell inside the window.')
        return ($lines -join [Environment]::NewLine)
    }
    foreach ($row in $rows) {
        $delta = [math]::Round((([datetime]$row.Time) - $latest).TotalSeconds, 1)
        [void]$lines.Add(("{0} ({1}s) | {2} | {3} | {4}" -f ([datetime]$row.Time).ToString('yyyy-MM-dd HH:mm:ss'), $delta, $row.Type, $row.Signal, $row.Detail))
        if ($row.Path) { [void]$lines.Add("  $($row.Path)") }
    }
    return ($lines -join [Environment]::NewLine)
}

function Get-DriverInventoryRows {
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop | Where-Object {
            $_.DeviceClass -match 'DISPLAY|HIDCLASS|USB|MEDIA|SYSTEM' -or
            $_.DeviceName -match 'NVIDIA|Intel|AMD|Logitech|Thrustmaster|Fanatec|MOZA|Xbox|Controller|Wheel|USB'
        } | Sort-Object DeviceClass, DeviceName | ForEach-Object {
            [void]$rows.Add([pscustomobject]@{
                DeviceName    = $_.DeviceName
                DeviceClass   = $_.DeviceClass
                Manufacturer  = $_.Manufacturer
                DriverVersion = $_.DriverVersion
                DriverDate    = $_.DriverDate
                InfName       = $_.InfName
                IsSigned      = $_.IsSigned
            })
        }
    }
    catch {}
    return $rows.ToArray()
}

function Get-InstallAuditRows {
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($install in Get-SteamInstallInfo) {
        [void]$rows.Add([pscustomobject]@{ Check = 'Steam library'; Status = 'Info'; Value = $install.Library; Path = $install.Library })
        [void]$rows.Add([pscustomobject]@{ Check = 'Library path length'; Status = if ($install.LibraryLength -le 59) { 'OK' } else { 'Warn' }; Value = "$($install.LibraryLength) chars"; Path = $install.Library })
        [void]$rows.Add([pscustomobject]@{ Check = 'Manifest'; Status = if (Test-Path -LiteralPath $install.Manifest) { 'OK' } else { 'Warn' }; Value = "StateFlags=$($install.StateFlags); SizeOnDisk=$($install.SizeOnDisk); LastUpdated=$($install.LastUpdated)"; Path = $install.Manifest })
        [void]$rows.Add([pscustomobject]@{ Check = 'Executable exists'; Status = if ($install.ExeExists) { 'OK' } else { 'Warn' }; Value = $install.ExeExists; Path = $install.Exe })
        if ($install.ExeExists) {
            try {
                $exe = Get-Item -LiteralPath $install.Exe -Force
                $version = $exe.VersionInfo.FileVersion
                $sig = Get-AuthenticodeSignature -LiteralPath $install.Exe -ErrorAction SilentlyContinue
                [void]$rows.Add([pscustomobject]@{ Check = 'Executable version'; Status = 'Info'; Value = $version; Path = $install.Exe })
                [void]$rows.Add([pscustomobject]@{ Check = 'Executable signature'; Status = if ($sig.Status -eq 'Valid') { 'OK' } else { 'Info' }; Value = "$($sig.Status) $($sig.SignerCertificate.Subject)"; Path = $install.Exe })
                [void]$rows.Add([pscustomobject]@{ Check = 'Executable timestamp'; Status = 'Info'; Value = $exe.LastWriteTime; Path = $install.Exe })
            }
            catch {
                [void]$rows.Add([pscustomobject]@{ Check = 'Executable metadata'; Status = 'Warn'; Value = $_.Exception.Message; Path = $install.Exe })
            }
        }
        if (Test-Path -LiteralPath $install.InstallDir) {
            try {
                $top = @(Get-ChildItem -LiteralPath $install.InstallDir -Force -ErrorAction Stop)
                [void]$rows.Add([pscustomobject]@{ Check = 'Top-level install items'; Status = 'Info'; Value = $top.Count; Path = $install.InstallDir })
                foreach ($item in $top | Sort-Object LastWriteTime -Descending | Select-Object -First 12) {
                    [void]$rows.Add([pscustomobject]@{ Check = 'Recent top-level install item'; Status = 'Read-only'; Value = "$($item.LastWriteTime) $($item.Name)"; Path = $item.FullName })
                }
            }
            catch {
                [void]$rows.Add([pscustomobject]@{ Check = 'Install folder listing'; Status = 'Warn'; Value = $_.Exception.Message; Path = $install.InstallDir })
            }
        }
    }
    if ($rows.Count -eq 0) {
        [void]$rows.Add([pscustomobject]@{ Check = 'Steam install detection'; Status = 'Warn'; Value = 'No Steam FH6 manifest was detected.'; Path = '' })
    }
    return $rows.ToArray()
}

function Test-TelemetryPortAvailability {
    param([int]$Port = 5606)
    $result = [pscustomobject]@{
        Port       = $Port
        Status     = 'Unknown'
        Detail     = ''
        ActiveRows = @()
    }
    try {
        $active = @(Get-NetUDPEndpoint -LocalPort $Port -ErrorAction SilentlyContinue)
        $result.ActiveRows = $active
        if ($active.Count -gt 0) {
            $owners = @()
            foreach ($row in $active) {
                $procName = ''
                try { $procName = (Get-Process -Id $row.OwningProcess -ErrorAction SilentlyContinue).ProcessName } catch {}
                $owners += "PID=$($row.OwningProcess) $procName Local=$($row.LocalAddress):$($row.LocalPort)"
            }
            $result.Status = 'Busy'
            $result.Detail = $owners -join '; '
        }
        else {
            $client = New-Object System.Net.Sockets.UdpClient($Port)
            $client.Close()
            $result.Status = 'Available'
            $result.Detail = 'Port can be bound by the telemetry listener.'
        }
    }
    catch {
        $result.Status = 'Warn'
        $result.Detail = $_.Exception.Message
    }
    return $result
}

function Get-TelemetryPreflightSummary {
    param([int]$Port = 5606)
    $portStatus = Test-TelemetryPortAvailability -Port $Port
    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add('FH6 Data Out Telemetry Preflight')
    [void]$lines.Add('================================')
    [void]$lines.Add("IP: 127.0.0.1")
    [void]$lines.Add("Port: $Port")
    [void]$lines.Add("Port status: $($portStatus.Status)")
    [void]$lines.Add("Detail: $($portStatus.Detail)")
    [void]$lines.Add('')
    [void]$lines.Add('In FH6 set:')
    [void]$lines.Add('  Settings > HUD and Gameplay > Data Out: On')
    [void]$lines.Add('  Data Out IP Address: 127.0.0.1')
    [void]$lines.Add("  Data Out IP Port: $Port")
    [void]$lines.Add('')
    [void]$lines.Add('The tool only listens. It sends no data back to FH6.')
    return ($lines -join [Environment]::NewLine)
}

function Get-RegistryValueSafe {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Name
    )
    try {
        $item = Get-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction Stop
        return $item.$Name
    }
    catch {
        return $null
    }
}

function Get-WindowsGamingSettingRows {
    $rows = New-Object System.Collections.Generic.List[object]
    function Add-Setting($Area, $Name, $Path, $ValueName, $Interpretation) {
        $value = Get-RegistryValueSafe -Path $Path -Name $ValueName
        [void]$rows.Add([pscustomobject]@{
            Area           = $Area
            Name           = $Name
            Value          = if ($null -eq $value) { '<missing>' } else { [string]$value }
            Interpretation = (& $Interpretation $value)
            Path           = "$Path\$ValueName"
        })
    }

    Add-Setting 'Game Mode' 'Auto Game Mode' 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' {
        param($v) if ($null -eq $v) { 'Missing; Windows default applies.' } elseif ([int]$v -eq 1) { 'Enabled.' } else { 'Disabled.' }
    }
    Add-Setting 'Game Bar' 'Game Bar startup panel' 'HKCU:\Software\Microsoft\GameBar' 'ShowStartupPanel' {
        param($v) if ($null -eq $v) { 'Missing.' } elseif ([int]$v -eq 1) { 'Enabled; overlay UI may appear.' } else { 'Disabled.' }
    }
    Add-Setting 'Capture' 'App capture' 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' 'AppCaptureEnabled' {
        param($v) if ($null -eq $v) { 'Missing.' } elseif ([int]$v -eq 1) { 'Enabled; capture stack may be active.' } else { 'Disabled.' }
    }
    Add-Setting 'Capture' 'GameDVR enabled' 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' {
        param($v) if ($null -eq $v) { 'Missing.' } elseif ([int]$v -eq 1) { 'Enabled; consider disabling during crash tests.' } else { 'Disabled.' }
    }
    Add-Setting 'Graphics' 'Hardware accelerated GPU scheduling' 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' {
        param($v)
        if ($null -eq $v) { 'Missing/default.' }
        elseif ([int]$v -eq 2) { 'Enabled.' }
        elseif ([int]$v -eq 1) { 'Disabled.' }
        else { "Unknown value $v." }
    }
    Add-Setting 'Display' 'MPO overlay test mode' 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm' 'OverlayTestMode' {
        param($v) if ($null -eq $v) { 'Missing/default.' } else { "Custom value $v present." }
    }
    return $rows.ToArray()
}

function Get-PowerThermalRows {
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        $active = (& powercfg /getactivescheme) 2>$null
        [void]$rows.Add([pscustomobject]@{ Area = 'Power'; Name = 'Active scheme'; Value = ($active -join ' ').Trim(); Detail = 'Use High performance/Best performance for crash repro tests on laptops.' })
    }
    catch {
        [void]$rows.Add([pscustomobject]@{ Area = 'Power'; Name = 'Active scheme'; Value = $_.Exception.Message; Detail = 'powercfg unavailable.' })
    }
    try {
        Get-CimInstance Win32_Battery -ErrorAction Stop | ForEach-Object {
            [void]$rows.Add([pscustomobject]@{ Area = 'Power'; Name = 'Battery'; Value = "Status=$($_.BatteryStatus); Charge=$($_.EstimatedChargeRemaining)%"; Detail = 'Prefer AC power for FH6 crash testing.' })
        }
    }
    catch {
        [void]$rows.Add([pscustomobject]@{ Area = 'Power'; Name = 'Battery'; Value = 'No battery data or desktop system.'; Detail = '' })
    }
    try {
        Get-CimInstance Win32_Processor -ErrorAction Stop | ForEach-Object {
            [void]$rows.Add([pscustomobject]@{ Area = 'CPU'; Name = $_.Name; Value = "Cores=$($_.NumberOfCores); Logical=$($_.NumberOfLogicalProcessors); MaxMHz=$($_.MaxClockSpeed)"; Detail = 'Read-only CPU inventory.' })
        }
    }
    catch {}
    return $rows.ToArray()
}

function Get-XboxAppPackageRows {
    $packageNames = @(
        'Microsoft.GamingServices',
        'Microsoft.GamingApp',
        'Microsoft.XboxIdentityProvider',
        'Microsoft.Xbox.TCUI',
        'Microsoft.XboxGamingOverlay',
        'Microsoft.WindowsStore',
        'Microsoft.StorePurchaseApp'
    )
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($name in $packageNames) {
        try {
            $pkgs = @(Get-AppxPackage -Name $name -ErrorAction Stop)
            if ($pkgs.Count -eq 0) {
                [void]$rows.Add([pscustomobject]@{ Name = $name; Status = 'Not found'; Version = ''; PackageFullName = ''; InstallLocation = '' })
            }
            foreach ($pkg in $pkgs) {
                [void]$rows.Add([pscustomobject]@{
                    Name            = $pkg.Name
                    Status          = 'Installed'
                    Version         = $pkg.Version.ToString()
                    PackageFullName = $pkg.PackageFullName
                    InstallLocation = $pkg.InstallLocation
                })
            }
        }
        catch {
            [void]$rows.Add([pscustomobject]@{ Name = $name; Status = 'Unavailable'; Version = ''; PackageFullName = $_.Exception.Message; InstallLocation = '' })
        }
    }
    return $rows.ToArray()
}

function Test-CompanionWritablePath {
    param([Parameter(Mandatory)][string]$Path)
    $full = Get-FullPathSafe -Path $Path
    if ($full -match '\\steamapps\\common\\ForzaHorizon6(\\|$)') {
        return [pscustomobject]@{ Path = $Path; Exists = Test-Path -LiteralPath $Path; Status = 'Skipped'; Detail = 'Never write-test the game install.' }
    }
    if (-not (Test-Path -LiteralPath $Path)) {
        return [pscustomobject]@{ Path = $Path; Exists = $false; Status = 'Missing'; Detail = 'Path does not exist.' }
    }
    $probe = Join-Path $Path ("fh6_companion_probe_{0}.tmp" -f ([guid]::NewGuid().ToString('N')))
    try {
        'FH6 Companion Doctor write probe' | Set-Content -LiteralPath $probe -Encoding ASCII -ErrorAction Stop
        Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
        return [pscustomobject]@{ Path = $Path; Exists = $true; Status = 'OK'; Detail = 'Temporary probe file created and removed.' }
    }
    catch {
        Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
        return [pscustomobject]@{ Path = $Path; Exists = $true; Status = 'Warn'; Detail = $_.Exception.Message }
    }
}

function Get-PathPermissionRows {
    $paths = @(
        $script:Config.LocalRoot,
        $script:Config.SharedRoot,
        $script:Config.XboxPgsRoot,
        $script:Config.BackupRoot,
        $script:Config.ReportRoot,
        $script:Config.SnapshotRoot,
        $script:Config.SessionRoot,
        $script:Config.TelemetryRoot
    ) | Where-Object { $_ } | Select-Object -Unique
    @($paths | ForEach-Object { Test-CompanionWritablePath -Path $_ })
}

function Get-BackupIntegrityRows {
    New-ToolDirectory
    $rows = New-Object System.Collections.Generic.List[object]
    $zips = @(Get-ChildItem -LiteralPath $script:Config.BackupRoot -File -Filter '*.zip' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 30)
    if ($zips.Count -eq 0) {
        [void]$rows.Add([pscustomobject]@{ Name = '<none>'; Status = 'Info'; Entries = 0; SizeMB = 0; Path = $script:Config.BackupRoot; Detail = 'No backup zips found yet.' })
        return $rows.ToArray()
    }
    Add-Type -AssemblyName System.IO.Compression.FileSystem -ErrorAction SilentlyContinue
    foreach ($zip in $zips) {
        $archive = $null
        try {
            $archive = [System.IO.Compression.ZipFile]::OpenRead($zip.FullName)
            $manifest = @($archive.Entries | Where-Object { $_.FullName -eq 'manifest.json' })
            [void]$rows.Add([pscustomobject]@{
                Name    = $zip.Name
                Status  = if ($manifest.Count -gt 0) { 'OK' } else { 'Warn' }
                Entries = $archive.Entries.Count
                SizeMB  = [math]::Round(($zip.Length / 1MB), 2)
                Path    = $zip.FullName
                Detail  = if ($manifest.Count -gt 0) { 'Manifest present.' } else { 'manifest.json missing; restore may be unsafe.' }
            })
        }
        catch {
            [void]$rows.Add([pscustomobject]@{ Name = $zip.Name; Status = 'Warn'; Entries = 0; SizeMB = [math]::Round(($zip.Length / 1MB), 2); Path = $zip.FullName; Detail = $_.Exception.Message })
        }
        finally {
            if ($archive) { $archive.Dispose() }
        }
    }
    return $rows.ToArray()
}

function Get-ReliabilityRecordRows {
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        Get-CimInstance -ClassName Win32_ReliabilityRecords -ErrorAction Stop | Where-Object {
            $_.Message -match 'forzahorizon6|Forza Horizon 6|ForzaHorizon6' -or
            $_.ProductName -match 'forzahorizon6|Forza Horizon 6|ForzaHorizon6' -or
            $_.SourceName -match 'forzahorizon6|Forza Horizon 6|ForzaHorizon6'
        } | Sort-Object TimeGenerated -Descending | Select-Object -First 60 | ForEach-Object {
            [void]$rows.Add([pscustomobject]@{
                TimeGenerated = $_.TimeGenerated
                SourceName    = $_.SourceName
                ProductName   = $_.ProductName
                EventId       = $_.EventIdentifier
                Message       = $_.Message
            })
        }
    }
    catch {
        [void]$rows.Add([pscustomobject]@{
            TimeGenerated = $null
            SourceName    = 'Unavailable'
            ProductName   = ''
            EventId       = ''
            Message       = $_.Exception.Message
        })
    }
    return $rows.ToArray()
}

function Get-DisplayTopologyRows {
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        Get-CimInstance Win32_VideoController -ErrorAction Stop | ForEach-Object {
            [void]$rows.Add([pscustomobject]@{
                Type        = 'GPU'
                Name        = $_.Name
                Detail      = "Mode=$($_.VideoModeDescription); Refresh=$($_.CurrentRefreshRate); RAM=$([math]::Round(($_.AdapterRAM / 1GB), 2)) GB"
                Driver      = $_.DriverVersion
                Status      = $_.Status
            })
        }
    }
    catch {}
    try {
        Get-CimInstance Win32_DesktopMonitor -ErrorAction Stop | ForEach-Object {
            [void]$rows.Add([pscustomobject]@{
                Type        = 'Monitor'
                Name        = $_.Name
                Detail      = "Width=$($_.ScreenWidth); Height=$($_.ScreenHeight); PNP=$($_.PNPDeviceID)"
                Driver      = ''
                Status      = $_.Status
            })
        }
    }
    catch {}
    return $rows.ToArray()
}

function Get-GraphicsPreferenceRows {
    $rows = New-Object System.Collections.Generic.List[object]
    $path = 'HKCU:\Software\Microsoft\DirectX\UserGpuPreferences'
    try {
        $props = Get-ItemProperty -LiteralPath $path -ErrorAction Stop
        foreach ($prop in $props.PSObject.Properties) {
            if ($prop.Name -in @('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider')) { continue }
            if ($prop.Name -match 'ForzaHorizon6|forzahorizon6|Forza Horizon 6|steamapps|2483190') {
                [void]$rows.Add([pscustomobject]@{
                    AppPath = $prop.Name
                    Value   = [string]$prop.Value
                    Source  = $path
                })
            }
        }
    }
    catch {}
    if ($rows.Count -eq 0) {
        [void]$rows.Add([pscustomobject]@{ AppPath = '<none>'; Value = 'No FH6-specific Windows graphics preference found.'; Source = $path })
    }
    return $rows.ToArray()
}

function Get-AppCompatLayerRows {
    $rows = New-Object System.Collections.Generic.List[object]
    $paths = @(
        'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers',
        'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers',
        'HKLM:\Software\WOW6432Node\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers'
    )
    foreach ($path in $paths) {
        try {
            $props = Get-ItemProperty -LiteralPath $path -ErrorAction Stop
            foreach ($prop in $props.PSObject.Properties) {
                if ($prop.Name -in @('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider')) { continue }
                if ($prop.Name -match 'ForzaHorizon6|forzahorizon6|Forza Horizon 6') {
                    [void]$rows.Add([pscustomobject]@{
                        AppPath = $prop.Name
                        Flags   = [string]$prop.Value
                        Source  = $path
                    })
                }
            }
        }
        catch {}
    }
    if ($rows.Count -eq 0) {
        [void]$rows.Add([pscustomobject]@{ AppPath = '<none>'; Flags = 'No FH6-specific compatibility layer flags found.'; Source = 'AppCompatFlags\Layers' })
    }
    return $rows.ToArray()
}

function Get-SecurityProductRows {
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        Get-CimInstance -Namespace root/SecurityCenter2 -ClassName AntivirusProduct -ErrorAction Stop | ForEach-Object {
            [void]$rows.Add([pscustomobject]@{
                Type              = 'Antivirus'
                DisplayName       = $_.displayName
                ProductState      = $_.productState
                PathToSignedProductExe = $_.pathToSignedProductExe
                PathToSignedReportingExe = $_.pathToSignedReportingExe
            })
        }
    }
    catch {
        [void]$rows.Add([pscustomobject]@{
            Type              = 'Antivirus'
            DisplayName       = 'Unavailable'
            ProductState      = ''
            PathToSignedProductExe = $_.Exception.Message
            PathToSignedReportingExe = ''
        })
    }
    return $rows.ToArray()
}

function Get-OfficialReferenceRows {
    @(
        [pscustomobject]@{
            Area = 'Official PC crash guide'
            Url  = 'https://support.forza.net/hc/en-us/articles/360007593074-My-Game-is-Not-Launching-or-is-Crashing-on-PC'
            Why  = 'Forza Support crash guide covering Gaming Services, drivers, clean boot, overlays, software conflicts, power settings, Game Mode, and support steps.'
        },
        [pscustomobject]@{
            Area = 'FH6 crash error codes'
            Url  = 'https://support.forza.net/hc/en-us/articles/51642089902739-Forza-Horizon-6-PC-Crash-Error-Codes'
            Why  = 'Official FH6 PC crash code reference.'
        },
        [pscustomobject]@{
            Area = 'FH6 Data Out'
            Url  = 'https://support.forza.net/hc/en-us/articles/51744149102611-Forza-Horizon-6-Data-Out-Documentation'
            Why  = 'Official one-way UDP telemetry format used by the Telemetry tab.'
        },
        [pscustomobject]@{
            Area = 'FH6 Steam install troubleshooting'
            Url  = 'https://support.forza.net/hc/en-us/articles/51673672925459-FH6-Steam-Installation-Troubleshooting'
            Why  = 'Official Steam install/path troubleshooting reference.'
        },
        [pscustomobject]@{
            Area = 'FH6 known issues'
            Url  = 'https://support.forza.net/hc/en-us/articles/51701860097811-Forza-Horizon-6-Known-Issues'
            Why  = 'Known-issues page for comparing current crash/device behavior.'
        },
        [pscustomobject]@{
            Area = 'FH6 wheels/devices'
            Url  = 'https://support.forza.net/hc/en-us/articles/51674028831251-FH6-Supported-Wheels-and-Devices'
            Why  = 'Device and wheel support reference used by the Devices tab guidance.'
        },
        [pscustomobject]@{
            Area = 'Forza Code of Conduct'
            Url  = 'https://support.forza.net/hc/en-us/articles/360035563914-Forza-Code-of-Conduct'
            Why  = 'Boundary reference: this tool avoids cheating, memory editing, file tampering, automation, trainers, and unlock/save manipulation.'
        }
    )
}

function Get-ToolFileRows {
    $files = @(
        (Join-Path $script:Config.Downloads 'FH6-CompanionDoctor.ps1'),
        (Join-Path $script:Config.Downloads 'Run-FH6-CompanionDoctor.cmd'),
        (Join-Path $script:Config.Downloads 'FH6-CompanionDoctor-README.txt'),
        (Join-Path $script:Config.Downloads 'FH6-SaveDoctor.ps1'),
        (Join-Path $script:Config.Downloads 'Run-FH6-SaveDoctor.cmd'),
        (Join-Path $script:Config.Downloads 'FH6-SaveDoctor-README.txt')
    ) | Select-Object -Unique
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($file in $files) {
        if (Test-Path -LiteralPath $file) {
            $item = Get-Item -LiteralPath $file -Force
            $hash = Get-FileHash -LiteralPath $file -Algorithm SHA256
            [void]$rows.Add([pscustomobject]@{
                Name          = $item.Name
                Path          = $item.FullName
                Length        = $item.Length
                LastWriteTime = $item.LastWriteTime
                SHA256        = $hash.Hash
            })
        }
    }
    return $rows.ToArray()
}

function Get-ToolSafetyAuditRows {
    $rows = New-Object System.Collections.Generic.List[object]
    $scriptPath = Join-Path $script:Config.Downloads 'FH6-CompanionDoctor.ps1'
    $source = if (Test-Path -LiteralPath $scriptPath) { Get-Content -LiteralPath $scriptPath -Raw } else { '' }
    $forbiddenPatterns = @(
        'WriteProcessMemory',
        'ReadProcessMemory',
        'OpenProcess',
        'CreateRemoteThread',
        'SetWindowsHookEx',
        'SendInput',
        'keybd_event',
        'mouse_event',
        'VirtualAllocEx',
        'ForzaHorizon6\\forzahorizon6.exe.*Remove-Item',
        'steamapps\\common\\ForzaHorizon6.*Remove-Item'
    )
    foreach ($pattern in $forbiddenPatterns) {
        $matched = $false
        if ($source) { $matched = [regex]::IsMatch($source, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase) }
        [void]$rows.Add([pscustomobject]@{
            Check  = "Forbidden pattern: $pattern"
            Status = if ($matched) { 'Warn' } else { 'OK' }
            Detail = if ($matched) { 'Pattern appeared in script text; review manually.' } else { 'Not present.' }
        })
    }
    [void]$rows.Add([pscustomobject]@{
        Check  = 'Game install modification policy'
        Status = 'OK'
        Detail = 'Assert-FH6SafeTarget refuses steamapps\common\ForzaHorizon6 and forzahorizon6.exe paths before cleanup actions.'
    })
    [void]$rows.Add([pscustomobject]@{
        Check  = 'Telemetry direction'
        Status = 'OK'
        Detail = 'Telemetry listener uses UDP receive only. It does not send data back to FH6.'
    })
    [void]$rows.Add([pscustomobject]@{
        Check  = 'Destructive action defaults'
        Status = 'OK'
        Detail = 'Backup is enabled by default; Dry Run is available; delete/rename operations require selected cleanable records.'
    })
    return $rows.ToArray()
}

function Invoke-CompanionSelfTest {
    $rows = New-Object System.Collections.Generic.List[object]
    function Add-Test($Name, $Status, $Detail) {
        [void]$rows.Add([pscustomobject]@{ Test = $Name; Status = $Status; Detail = $Detail })
    }

    try {
        $tokens = $null; $errors = $null
        [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $script:Config.Downloads 'FH6-CompanionDoctor.ps1'), [ref]$tokens, [ref]$errors) | Out-Null
        Add-Test 'PowerShell parser' ($(if ($errors.Count -eq 0) { 'OK' } else { 'Warn' })) "$($errors.Count) parser error(s)"
    }
    catch { Add-Test 'PowerShell parser' 'Warn' $_.Exception.Message }

    try { Add-Test 'Steam install detection' ($(if (@(Get-SteamInstallInfo).Count -gt 0) { 'OK' } else { 'Warn' })) "$(@(Get-SteamInstallInfo).Count) install row(s)" } catch { Add-Test 'Steam install detection' 'Warn' $_.Exception.Message }
    try { Add-Test 'FH6 inventory' 'OK' "$(@(Get-FH6Inventory).Count) inventory row(s)" } catch { Add-Test 'FH6 inventory' 'Warn' $_.Exception.Message }
    try { Add-Test 'Health collectors' 'OK' "$(@(Get-HealthRows).Count) health row(s)" } catch { Add-Test 'Health collectors' 'Warn' $_.Exception.Message }
    try { Add-Test 'Crash collectors' 'OK' "$(@(Get-CrashEventRows).Count) crash event row(s); $(@(Get-CrashReportRows).Count) FH6 report row(s)" } catch { Add-Test 'Crash collectors' 'Warn' $_.Exception.Message }
    try { Add-Test 'Telemetry port 5606' (Test-TelemetryPortAvailability -Port 5606).Status (Test-TelemetryPortAvailability -Port 5606).Detail } catch { Add-Test 'Telemetry port 5606' 'Warn' $_.Exception.Message }
    try {
        $audit = @(Get-ToolSafetyAuditRows)
        $warnings = @($audit | Where-Object { $_.Status -eq 'Warn' }).Count
        Add-Test 'Safety audit' ($(if ($warnings -eq 0) { 'OK' } else { 'Warn' })) "$warnings warning row(s)"
    }
    catch { Add-Test 'Safety audit' 'Warn' $_.Exception.Message }
    try {
        $snap = New-StateSnapshot -Label 'selftest'
        Add-Test 'Snapshot writer' ($(if ((Test-Path -LiteralPath $snap.Json) -and (Test-Path -LiteralPath $snap.Text)) { 'OK' } else { 'Warn' })) "$($snap.Json)"
    }
    catch { Add-Test 'Snapshot writer' 'Warn' $_.Exception.Message }

    return $rows.ToArray()
}

function Write-ToolManifest {
    New-ToolDirectory
    $manifest = [pscustomobject]@{
        ToolName        = 'FH6 Companion Doctor'
        Version         = '4.0'
        GeneratedAt     = (Get-Date).ToString('o')
        SafetyBoundary  = @(
            'No game install modification',
            'No forzahorizon6.exe modification',
            'No memory read/write',
            'No injection/hooks',
            'No gameplay/input automation',
            'No save editing for advantage/unlocks/currency'
        )
        Folders         = [pscustomobject]@{
            Backups   = $script:Config.BackupRoot
            Reports   = $script:Config.ReportRoot
            Packages  = $script:Config.PackageRoot
            Logs      = $script:Config.LogRoot
            Telemetry = $script:Config.TelemetryRoot
            Snapshots = $script:Config.SnapshotRoot
            Sessions  = $script:Config.SessionRoot
            Bundles   = $script:Config.BundleRoot
        }
        Files           = @(Get-ToolFileRows)
        OfficialReferences = @(Get-OfficialReferenceRows)
        SafetyAudit     = @(Get-ToolSafetyAuditRows)
    }
    $manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $script:Config.ManifestPath -Encoding UTF8
    return $script:Config.ManifestPath
}

function New-PortableToolBundle {
    param([scriptblock]$Log = { param($m) Write-Host $m })
    New-ToolDirectory
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $stage = Join-Path $env:TEMP "FH6_CompanionDoctor_Portable_$stamp"
    $zip = Join-Path $script:Config.BundleRoot "FH6_CompanionDoctor_Portable_$stamp.zip"
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    try {
        $manifestPath = Write-ToolManifest
        foreach ($file in Get-ToolFileRows) {
            & $Log "Adding tool file: $($file.Name)"
            Copy-Item -LiteralPath $file.Path -Destination (Join-Path $stage $file.Name) -Force
        }
        Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $stage (Split-Path $manifestPath -Leaf)) -Force
        Get-OfficialReferenceRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'official-references.json') -Encoding UTF8
        Get-ToolSafetyAuditRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'safety-audit.json') -Encoding UTF8
        Invoke-CompanionSelfTest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'self-test.json') -Encoding UTF8
        $readme = @"
FH6 Companion Doctor Portable Bundle
Generated: $(Get-Date)

Run:
  Run-FH6-CompanionDoctor.cmd

Safety:
  This external tool does not modify FH6 game install files, does not inject into
  the game, does not read/write game memory, and does not automate gameplay.

Included:
  - Tool scripts and launcher
  - README
  - Manifest with SHA256 hashes
  - Official references
  - Safety audit
  - Self-test output
"@
        $readme | Set-Content -LiteralPath (Join-Path $stage 'PORTABLE-BUNDLE-README.txt') -Encoding UTF8
        $content = @(Get-ChildItem -LiteralPath $stage -Force | Select-Object -ExpandProperty FullName)
        Compress-Archive -LiteralPath $content -DestinationPath $zip -Force
        & $Log "Portable bundle written: $zip"
        return $zip
    }
    finally {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

function Get-ExpertRecommendationRows {
    $rows = New-Object System.Collections.Generic.List[object]
    function Add-Recommendation($Priority, $Area, $Finding, $Action, $Evidence) {
        [void]$rows.Add([pscustomobject]@{
            Priority = $Priority
            Area     = $Area
            Finding  = $Finding
            Action   = $Action
            Evidence = $Evidence
        })
    }

    $events = @(Get-CrashEventRows)
    $conflicts = @(Get-ConflictProcesses)
    $wer = @(Get-WERReportRows)
    $redists = @(Get-VisualCRedistRows)
    $mf = Get-MediaFoundationStatus
    $installs = @(Get-SteamInstallInfo)
    $gs = Get-GamingServicesVersion
    $mitigations = @(Get-ProcessMitigationRows)
    $startup = @(Get-StartupProgramRows)
    $gamingSettings = @(Get-WindowsGamingSettingRows)
    $permissionRows = @(Get-PathPermissionRows)
    $packages = @(Get-XboxAppPackageRows)
    $backupRows = @(Get-BackupIntegrityRows)
    $reliabilityRows = @(Get-ReliabilityRecordRows | Where-Object { $_.SourceName -ne 'Unavailable' })
    $compatRows = @(Get-AppCompatLayerRows | Where-Object { $_.AppPath -ne '<none>' })
    $graphicsPrefs = @(Get-GraphicsPreferenceRows | Where-Object { $_.AppPath -ne '<none>' })
    $securityRows = @(Get-SecurityProductRows | Where-Object { $_.DisplayName -ne 'Unavailable' })

    $accessViolations = @($events | Where-Object { $_.Code -in @('0xc0000005','c0000005') })
    if ($accessViolations.Count -ge 3) {
        Add-Recommendation 1 'Crash Pattern' 'Repeated access-violation/BEX-style crashes detected.' 'Prioritize conflict process isolation, clean boot, graphics/runtime repair, and support package capture over more save wipes.' "$($accessViolations.Count) matching event(s)"
    }
    if ($conflicts.Count -gt 0) {
        Add-Recommendation 1 'Background Processes' 'Possible overlay/hook/conflict process detected.' 'Stop these tools before launching FH6, especially capture overlays, performance monitors, tuning tools, and input hooks.' (($conflicts | Select-Object -ExpandProperty ProcessName -Unique) -join ', ')
    }
    $captureActive = @($gamingSettings | Where-Object { $_.Area -in @('Game Bar','Capture') -and $_.Interpretation -match 'Enabled|active' })
    if ($captureActive.Count -gt 0) {
        Add-Recommendation 2 'Windows Gaming Settings' 'Game Bar or capture stack appears enabled.' 'Disable Windows capture/Game Bar features for one clean repro attempt.' (($captureActive | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join '; ')
    }
    $permissionWarnings = @($permissionRows | Where-Object { $_.Status -eq 'Warn' })
    if ($permissionWarnings.Count -gt 0) {
        Add-Recommendation 1 'Permissions' 'FH6/tool user-data path write warning detected.' 'Check folder permissions and security software for the warned paths before further save/cache cleanup.' (($permissionWarnings | ForEach-Object { "$($_.Path): $($_.Detail)" }) -join '; ')
    }
    $packageWarnings = @($packages | Where-Object { $_.Status -ne 'Installed' })
    if ($packageWarnings.Count -gt 0) {
        Add-Recommendation 2 'Xbox Apps' 'One or more Xbox/Store support packages are missing or unavailable.' 'Update/repair Xbox app, Microsoft Store, Xbox Identity Provider, and Gaming Services.' (($packageWarnings | ForEach-Object { "$($_.Name): $($_.Status)" }) -join '; ')
    }
    $backupWarnings = @($backupRows | Where-Object { $_.Status -eq 'Warn' })
    if ($backupWarnings.Count -gt 0) {
        Add-Recommendation 3 'Backups' 'One or more backup zips may not be safely restorable.' 'Keep using current Companion Doctor backups; avoid restoring archives without manifest.json.' (($backupWarnings | Select-Object -ExpandProperty Name) -join ', ')
    }
    if ($compatRows.Count -gt 0) {
        Add-Recommendation 2 'Compatibility' 'FH6-specific Windows compatibility layer flags are present.' 'Remove compatibility/admin/fullscreen-optimization flags for one clean repro attempt.' (($compatRows | ForEach-Object { "$($_.AppPath): $($_.Flags)" }) -join '; ')
    }
    if ($graphicsPrefs.Count -gt 0) {
        Add-Recommendation 3 'Graphics Preference' 'Windows has FH6-specific GPU preference entries.' 'If using a laptop/hybrid GPU, verify FH6 is assigned to the intended high-performance GPU.' (($graphicsPrefs | ForEach-Object { "$($_.AppPath): $($_.Value)" }) -join '; ')
    }
    if ($reliabilityRows.Count -gt 0) {
        Add-Recommendation 3 'Reliability Monitor' 'FH6 appears in Windows Reliability Monitor records.' 'Compare Reliability records with Event Timeline and session snapshots after the next crash.' "$($reliabilityRows.Count) reliability row(s)"
    }
    if ($securityRows.Count -gt 1) {
        Add-Recommendation 3 'Security Software' 'Multiple security products are visible.' 'For one clean repro, reduce unnecessary real-time scanners/overlays and avoid quarantining FH6 user/cache paths.' (($securityRows | Select-Object -ExpandProperty DisplayName) -join ', ')
    }
    if ($wer.Count -gt 0) {
        Add-Recommendation 2 'Crash Evidence' 'WER report folders exist for FH6.' 'Build a support package after reproducing the crash so WER/FH6/Event Viewer data is bundled together.' "$($wer.Count) WER folder(s)"
    }
    if ($mf.Status -ne 'OK') {
        Add-Recommendation 1 'Runtime' 'Media Foundation components appear missing.' 'Install/repair Windows Media Feature Pack or Media Foundation components before retrying.' $mf.Detail
    }
    $hasModernRedist = @($redists | Where-Object {
        $_.Name -match '2015-2022|2015.*2022|2017|2019|2022|v14' -or
        ($_.Version -and ([version]$_.Version -ge [version]'14.0.0.0'))
    }).Count -gt 0
    if (-not $hasModernRedist) {
        Add-Recommendation 1 'Runtime' 'Modern Visual C++ Redistributable was not detected.' 'Install/repair the latest x64 and x86 Microsoft Visual C++ Redistributables.' "$($redists.Count) redistributable entry/entries found"
    }
    try {
        if ([version]$gs -lt [version]'36.113.2002.0') {
            Add-Recommendation 1 'Gaming Services' 'Gaming Services is below FH6 minimum version.' 'Update Gaming Services from Microsoft Store before launching FH6.' $gs
        }
    }
    catch {
        Add-Recommendation 2 'Gaming Services' 'Gaming Services version could not be parsed.' 'Open Microsoft Store Downloads and check for Gaming Services updates.' $gs
    }
    foreach ($install in $installs) {
        if ($install.LibraryLength -gt 59) {
            Add-Recommendation 1 'Steam Install' 'Steam library path exceeds FH6 supported path-length guidance.' 'Move FH6 to a Steam library path with 59 characters or fewer.' "$($install.LibraryLength) chars: $($install.Library)"
        }
        if (-not $install.ExeExists) {
            Add-Recommendation 1 'Steam Install' 'FH6 executable was not found.' 'Use Steam Verify Integrity or reinstall FH6.' $install.Exe
        }
    }
    if ($events.Count -gt 0 -and $conflicts.Count -eq 0) {
        Add-Recommendation 3 'Clean Boot' 'Crashes continue but no common conflict process is currently visible.' 'Use a clean boot or temporarily disable nonessential startup apps, then retry.' "$($startup.Count) startup item(s) inventoried"
    }
    if (@($mitigations | Where-Object { $_.Scope -eq 'Image' -and $_.Area -ne 'Unavailable' }).Count -gt 0) {
        Add-Recommendation 3 'Exploit Protection' 'Image-specific process mitigation settings exist for FH6 executable name.' 'Review Windows Exploit Protection entries if crashes remain unchanged after clean boot.' 'Image mitigation rows found'
    }
    if ($rows.Count -eq 0) {
        Add-Recommendation 4 'Status' 'No urgent expert findings were generated.' 'Use Preflight + Launch, then create a snapshot/support package if the crash reproduces.' 'No high-priority rule matched'
    }

    return @($rows | Sort-Object Priority, Area)
}

function Get-ExpertRecommendationSummary {
    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add('Expert Recommendation Scorecard')
    [void]$lines.Add('===============================')
    foreach ($r in Get-ExpertRecommendationRows) {
        [void]$lines.Add("[P$($r.Priority)] $($r.Area): $($r.Finding)")
        [void]$lines.Add("  Action: $($r.Action)")
        [void]$lines.Add("  Evidence: $($r.Evidence)")
    }
    return ($lines -join [Environment]::NewLine)
}

function Get-DeviceRows {
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        $regex = 'Logitech|Thrustmaster|Fanatec|MOZA|Turtle|HORI|Mad Catz|Xbox|Controller|Wheel|Pedal|Shifter|HID|USB Hub|Driving'
        Get-CimInstance Win32_PnPEntity -ErrorAction Stop | Where-Object {
            $_.Name -match $regex -or $_.PNPClass -match 'HIDClass|USB|MEDIA'
        } | Sort-Object Name | ForEach-Object {
            [void]$rows.Add([pscustomobject]@{
                Name         = $_.Name
                Status       = $_.Status
                Class        = $_.PNPClass
                Manufacturer = $_.Manufacturer
                DeviceId     = $_.DeviceID
            })
        }
    }
    catch {}
    return $rows.ToArray()
}

function Get-HealthRows {
    $rows = New-Object System.Collections.Generic.List[object]
    function Add-Health($Area, $Check, $Status, $Detail, $Recommendation) {
        [void]$rows.Add([pscustomobject]@{
            Area           = $Area
            Check          = $Check
            Status         = $Status
            Detail         = $Detail
            Recommendation = $Recommendation
        })
    }

    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    Add-Health 'Account' 'Administrator' ($(if ($principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { 'OK' } else { 'Info' })) "User=$env:USERNAME" 'Some official troubleshooting steps require admin, but routine scans do not.'

    $gs = Get-GamingServicesVersion
    $gsStatus = 'Warn'
    try { if ([version]$gs -ge [version]'36.113.2002.0') { $gsStatus = 'OK' } } catch {}
    Add-Health 'Gaming Services' 'Version' $gsStatus $gs 'FH6 requires Gaming Services 36.113.2002.0 or newer.'

    foreach ($install in Get-SteamInstallInfo) {
        $pathStatus = if ($install.LibraryLength -le 59) { 'OK' } else { 'Warn' }
        Add-Health 'Steam' 'Library path length' $pathStatus "$($install.LibraryLength) chars: $($install.Library)" 'FH6 Steam library path should be 59 characters or shorter.'
        Add-Health 'Steam' 'Game executable' ($(if ($install.ExeExists) { 'OK' } else { 'Warn' })) $install.Exe 'Use Steam verify integrity if the executable is missing.'
        Add-Health 'Steam' 'Manifest state' 'Info' "StateFlags=$($install.StateFlags); LastUpdated=$($install.LastUpdated)" 'StateFlags 4 usually means installed/ready.'
    }
    if (@(Get-SteamInstallInfo).Count -eq 0) {
        Add-Health 'Steam' 'Install detection' 'Warn' 'No appmanifest_2483190.acf found.' 'Install through Steam or confirm a different launcher/version.'
    }

    try {
        $os = Get-CimInstance Win32_OperatingSystem
        Add-Health 'Windows' 'OS' 'Info' "$($os.Caption) build $($os.BuildNumber)" 'Keep Windows updated.'
        Add-Health 'Windows' 'Free memory' 'Info' ("{0:N1} GB free physical memory" -f ($os.FreePhysicalMemory / 1MB)) 'Close heavy background apps before crash testing.'
    }
    catch {
        Add-Health 'Windows' 'OS query' 'Warn' $_.Exception.Message 'Run as administrator if WMI/CIM is blocked.'
    }

    try {
        Get-CimInstance Win32_VideoController | ForEach-Object {
            Add-Health 'GPU' $_.Name 'Info' "Driver=$($_.DriverVersion); Date=$($_.DriverDate)" 'Use the latest stable vendor driver; test without overlays.'
        }
    }
    catch {
        Add-Health 'GPU' 'GPU query' 'Warn' $_.Exception.Message 'Run dxdiag support package.'
    }

    $driverRows = @(Get-DriverInventoryRows)
    Add-Health 'Drivers' 'Driver inventory' 'Info' "$($driverRows.Count) display/HID/USB/media/system driver row(s)" 'Use Driver Inventory when comparing graphics/input/USB driver state after changes.'

    $installAudit = @(Get-InstallAuditRows)
    $installWarnings = @($installAudit | Where-Object { $_.Status -eq 'Warn' }).Count
    Add-Health 'Install Audit' 'Read-only install checks' ($(if ($installWarnings -eq 0) { 'OK' } else { 'Warn' })) "$($installAudit.Count) row(s), $installWarnings warning(s)" 'Use Steam Verify Integrity only from Steam UI if install audit warnings appear.'

    $telemetryPort = Test-TelemetryPortAvailability -Port 5606
    Add-Health 'Telemetry' 'Default Data Out port 5606' ($(if ($telemetryPort.Status -eq 'Available') { 'OK' } elseif ($telemetryPort.Status -eq 'Busy') { 'Warn' } else { 'Info' })) $telemetryPort.Detail 'If busy, choose another port in the Telemetry tab and set the same port in FH6 Data Out.'

    $gamingSettings = @(Get-WindowsGamingSettingRows)
    $captureActive = @($gamingSettings | Where-Object { $_.Area -in @('Game Bar','Capture') -and $_.Interpretation -match 'Enabled|active' }).Count
    Add-Health 'Windows Gaming' 'Game Bar/Capture settings' ($(if ($captureActive -gt 0) { 'Warn' } else { 'OK' })) "$captureActive capture/overlay-related setting(s) appear enabled" 'Disable Game Bar/capture features during a clean crash repro test.'

    $powerRows = @(Get-PowerThermalRows)
    $powerScheme = @($powerRows | Where-Object { $_.Name -eq 'Active scheme' } | Select-Object -First 1)
    Add-Health 'Power' 'Active power profile' 'Info' ($(if ($powerScheme.Count) { $powerScheme[0].Value } else { 'Unknown' })) 'Use AC power and a high-performance profile during crash testing.'

    $packages = @(Get-XboxAppPackageRows)
    $missingPackages = @($packages | Where-Object { $_.Status -ne 'Installed' }).Count
    Add-Health 'Xbox Apps' 'Package inventory' ($(if ($missingPackages -eq 0) { 'OK' } else { 'Warn' })) "$($packages.Count) package rows, $missingPackages missing/unavailable" 'Repair/update Xbox app, Store, Identity Provider, and Gaming Services if package warnings appear.'

    $permissionRows = @(Get-PathPermissionRows)
    $permissionWarnings = @($permissionRows | Where-Object { $_.Status -eq 'Warn' }).Count
    Add-Health 'Permissions' 'FH6/tool writable paths' ($(if ($permissionWarnings -eq 0) { 'OK' } else { 'Warn' })) "$($permissionRows.Count) path(s), $permissionWarnings write warning(s)" 'If FH6 user/cache roots are unwritable, permissions or security software may block profile creation.'

    $backupRows = @(Get-BackupIntegrityRows)
    $backupWarnings = @($backupRows | Where-Object { $_.Status -eq 'Warn' }).Count
    Add-Health 'Backups' 'Backup zip integrity' ($(if ($backupWarnings -eq 0) { 'OK' } else { 'Warn' })) "$($backupRows.Count) backup row(s), $backupWarnings warning(s)" 'Backups should include manifest.json so restore can target original paths safely.'

    $reliabilityRows = @(Get-ReliabilityRecordRows | Where-Object { $_.SourceName -ne 'Unavailable' })
    Add-Health 'Reliability' 'Reliability Monitor records' ($(if ($reliabilityRows.Count -gt 0) { 'Warn' } else { 'Info' })) "$($reliabilityRows.Count) FH6 reliability record(s)" 'Reliability Monitor records can confirm crash timing even when local FH6 reports are sparse.'

    $displayRows = @(Get-DisplayTopologyRows)
    Add-Health 'Display' 'GPU/display topology' 'Info' "$($displayRows.Count) GPU/monitor row(s)" 'Use Display Topology to compare resolution, refresh, GPU, and monitor context.'

    $graphicsPrefs = @(Get-GraphicsPreferenceRows | Where-Object { $_.AppPath -ne '<none>' })
    Add-Health 'Graphics Preference' 'FH6 Windows GPU preference' ($(if ($graphicsPrefs.Count -gt 0) { 'Info' } else { 'OK' })) "$($graphicsPrefs.Count) FH6-specific preference row(s)" 'If crashes differ by GPU mode, review Windows graphics preference for FH6.'

    $compatRows = @(Get-AppCompatLayerRows | Where-Object { $_.AppPath -ne '<none>' })
    Add-Health 'Compatibility' 'FH6 compatibility layer flags' ($(if ($compatRows.Count -gt 0) { 'Warn' } else { 'OK' })) "$($compatRows.Count) FH6-specific compatibility row(s)" 'Remove forced compatibility/admin/fullscreen flags for one clean crash repro attempt if present.'

    $securityRows = @(Get-SecurityProductRows)
    Add-Health 'Security' 'Security product inventory' 'Info' "$($securityRows.Count) security product row(s)" 'Security software can block writes or inject scanning hooks; test with controlled exclusions only if trusted and necessary.'

    try {
        Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
            Add-Health 'Storage' $_.DeviceID 'Info' ("Free={0:N1} GB Total={1:N1} GB" -f ($_.FreeSpace / 1GB), ($_.Size / 1GB)) 'Keep enough free disk space for updates and shader/cache writes.'
        }
    }
    catch {}

    $conflicts = @(Get-ConflictProcesses)
    Add-Health 'Processes' 'Overlay/conflict scan' ($(if ($conflicts.Count -eq 0) { 'OK' } else { 'Warn' })) "$($conflicts.Count) possible match(es)" 'Disable overlays, monitoring, capture, input-hook, and tuning tools while testing.'

    $services = @(Get-XboxServiceRows)
    foreach ($svc in $services) {
        $status = if ($svc.Status -eq 'Running' -or $svc.Status -eq 'Stopped') { 'Info' } elseif ($svc.Status -eq 'Not found') { 'Warn' } else { 'Info' }
        Add-Health 'Xbox Services' $svc.Name $status "$($svc.Status) $($svc.StartType)" 'If FH6 authentication/cloud/game-save issues appear, repair Gaming Services and Xbox app components.'
    }

    $redists = @(Get-VisualCRedistRows)
    $hasModernRedist = @($redists | Where-Object {
        $_.Name -match '2015-2022|2015.*2022|2017|2019|2022|v14' -or
        ($_.Version -and ([version]$_.Version -ge [version]'14.0.0.0'))
    }).Count -gt 0
    Add-Health 'Runtime' 'Visual C++ redistributables' ($(if ($hasModernRedist) { 'OK' } else { 'Warn' })) "$($redists.Count) Visual C++ redistributable entries found" 'Install/repair the latest Microsoft Visual C++ Redistributable if crashes persist.'

    $mf = Get-MediaFoundationStatus
    Add-Health 'Runtime' 'Media Foundation' $mf.Status $mf.Detail 'FH6 error FH601 relates to Microsoft Media Foundation; install the Media Feature Pack on Windows N if needed.'

    $wer = @(Get-WERReportRows)
    Add-Health 'Crash Lab' 'WER report folders' ($(if ($wer.Count -gt 0) { 'Warn' } else { 'Info' })) "$($wer.Count) FH6 WER folder(s) found" 'Include WER data in a support package after reproducing the crash.'

    $steamLogRows = @(Get-SteamLogRows)
    Add-Health 'Steam' 'Log matches' ($(if ($steamLogRows.Count -gt 0) { 'Info' } else { 'Info' })) "$($steamLogRows.Count) FH6/app/cloud log match(es)" 'Use Steam Logs to inspect cloud/sync/content activity around launch attempts.'

    $events = @(Get-CrashEventRows)
    $latest = if ($events.Count) { "$($events[0].Time) $($events[0].EventName) $($events[0].Code)" } else { 'No recent FH6 crash events found.' }
    Add-Health 'Crash Lab' 'Latest crash' ($(if ($events.Count) { 'Warn' } else { 'OK' })) $latest 'Export support package after reproducing a crash.'

    return $rows.ToArray()
}

function Get-StatusSummary {
    $processes = @(Get-FH6Process)
    $installs = @(Get-SteamInstallInfo)
    $installText = if ($installs.Count) { ($installs | ForEach-Object { "$($_.Exe) exists=$($_.ExeExists)" }) -join '; ' } else { 'Steam FH6 install not detected' }
    return @"
Game process running: $($processes.Count -gt 0)
Gaming Services: $(Get-GamingServicesVersion)
Steam install: $installText
Local FH6 root: $($script:Config.LocalRoot)
Xbox GameSave root: $($script:Config.XboxPgsRoot)
Backups: $($script:Config.BackupRoot)
Reports: $($script:Config.ReportRoot)
Support packages: $($script:Config.PackageRoot)
Logs: $($script:Config.LogRoot)
Snapshots: $($script:Config.SnapshotRoot)
Sessions: $($script:Config.SessionRoot)
Portable bundles: $($script:Config.BundleRoot)
Telemetry: configure FH6 Data Out to IP 127.0.0.1 and the port shown in the Telemetry tab.
Steam Cloud: turn it off in Steam > FH6 > Properties > General before deleting saves.
"@
}

function Export-FH6Report {
    param([object[]]$Records = @())
    New-ToolDirectory
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $path = Join-Path $script:Config.ReportRoot "FH6_CompanionDoctor_Report_$stamp.txt"
    $body = New-Object System.Collections.Generic.List[string]
    [void]$body.Add("FH6 Companion Doctor Report")
    [void]$body.Add("Generated: $(Get-Date)")
    [void]$body.Add("")
    [void]$body.Add("== Status ==")
    [void]$body.Add((Get-StatusSummary))
    [void]$body.Add("")
    [void]$body.Add("== Health ==")
    foreach ($h in Get-HealthRows) {
        [void]$body.Add("[$($h.Status)] $($h.Area) / $($h.Check): $($h.Detail)")
        [void]$body.Add("  $($h.Recommendation)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Inventory ==")
    foreach ($record in $Records | Sort-Object Category, Path) {
        [void]$body.Add("[$($record.Category)] exists=$($record.Exists) cleanable=$($record.Cleanable) sizeMB=$($record.SizeMB) items=$($record.Items) modified=$($record.LastWriteTime)")
        [void]$body.Add("  $($record.Path)")
        [void]$body.Add("  $($record.Description)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Crashes ==")
    [void]$body.Add((Get-CrashSummary))
    [void]$body.Add("")
    [void]$body.Add("== Crash Signature Analysis ==")
    [void]$body.Add((Get-CrashSignatureAnalysis))
    [void]$body.Add("")
    [void]$body.Add("== Expert Recommendations ==")
    [void]$body.Add((Get-ExpertRecommendationSummary))
    [void]$body.Add("")
    [void]$body.Add("== Tool Self-Test ==")
    foreach ($t in Invoke-CompanionSelfTest) {
        [void]$body.Add("[$($t.Status)] $($t.Test): $($t.Detail)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Tool Safety Audit ==")
    foreach ($a in Get-ToolSafetyAuditRows) {
        [void]$body.Add("[$($a.Status)] $($a.Check): $($a.Detail)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Official References ==")
    foreach ($ref in Get-OfficialReferenceRows) {
        [void]$body.Add("$($ref.Area): $($ref.Url)")
        [void]$body.Add("  $($ref.Why)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Event Timeline ==")
    [void]$body.Add((Get-EventTimelineSummary))
    [void]$body.Add("")
    [void]$body.Add("== Latest Crash Correlation ==")
    [void]$body.Add((Get-CrashCorrelationSummary -Minutes 10))
    [void]$body.Add("")
    [void]$body.Add("== Conflicts ==")
    [void]$body.Add((Get-ConflictSummary))
    [void]$body.Add("")
    [void]$body.Add("== Steam Logs ==")
    [void]$body.Add((Get-SteamLogSummary))
    [void]$body.Add("")
    [void]$body.Add("== Xbox Services ==")
    foreach ($s in Get-XboxServiceRows) {
        [void]$body.Add("$($s.Name) | $($s.Status) | $($s.StartType) | $($s.DisplayName)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Visual C++ Redistributables ==")
    foreach ($v in Get-VisualCRedistRows) {
        [void]$body.Add("$($v.Name) | Version=$($v.Version) | InstallDate=$($v.InstallDate)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Media Foundation ==")
    $mf = Get-MediaFoundationStatus
    [void]$body.Add("$($mf.Status): $($mf.Detail)")
    [void]$body.Add("")
    [void]$body.Add("== WER Reports ==")
    foreach ($w in Get-WERReportRows) {
        [void]$body.Add("$($w.LastWriteTime) | $($w.EventType) | $($w.Name) | $($w.Path)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Startup Programs ==")
    foreach ($s in Get-StartupProgramRows) {
        [void]$body.Add("$($s.Source) | $($s.Scope) | $($s.Name) | $($s.Command)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Process Mitigations ==")
    foreach ($m in Get-ProcessMitigationRows) {
        [void]$body.Add("$($m.Scope) | $($m.Area) | $($m.Setting) | $($m.Value)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Driver Inventory ==")
    foreach ($d in Get-DriverInventoryRows) {
        [void]$body.Add("$($d.DeviceClass) | $($d.DeviceName) | $($d.DriverVersion) | $($d.Manufacturer) | Signed=$($d.IsSigned)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Read-only Install Audit ==")
    foreach ($a in Get-InstallAuditRows) {
        [void]$body.Add("[$($a.Status)] $($a.Check): $($a.Value)")
        if ($a.Path) { [void]$body.Add("  $($a.Path)") }
    }
    [void]$body.Add("")
    [void]$body.Add("== Telemetry Port Preflight ==")
    [void]$body.Add((Get-TelemetryPreflightSummary -Port 5606))
    [void]$body.Add("")
    [void]$body.Add("== Windows Gaming Settings ==")
    foreach ($g in Get-WindowsGamingSettingRows) {
        [void]$body.Add("$($g.Area) | $($g.Name) | $($g.Value) | $($g.Interpretation)")
        [void]$body.Add("  $($g.Path)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Power and Thermal ==")
    foreach ($p in Get-PowerThermalRows) {
        [void]$body.Add("$($p.Area) | $($p.Name) | $($p.Value) | $($p.Detail)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Xbox App Packages ==")
    foreach ($pkg in Get-XboxAppPackageRows) {
        [void]$body.Add("$($pkg.Name) | $($pkg.Status) | $($pkg.Version) | $($pkg.PackageFullName)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Path Permissions ==")
    foreach ($perm in Get-PathPermissionRows) {
        [void]$body.Add("$($perm.Status) | Exists=$($perm.Exists) | $($perm.Path) | $($perm.Detail)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Backup Integrity ==")
    foreach ($backup in Get-BackupIntegrityRows) {
        [void]$body.Add("$($backup.Status) | $($backup.Name) | entries=$($backup.Entries) | sizeMB=$($backup.SizeMB) | $($backup.Detail)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Reliability Records ==")
    foreach ($r in Get-ReliabilityRecordRows) {
        [void]$body.Add("$($r.TimeGenerated) | $($r.SourceName) | $($r.ProductName) | $($r.EventId) | $($r.Message)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Display Topology ==")
    foreach ($d in Get-DisplayTopologyRows) {
        [void]$body.Add("$($d.Type) | $($d.Name) | $($d.Detail) | Driver=$($d.Driver) | Status=$($d.Status)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Graphics Preferences ==")
    foreach ($g in Get-GraphicsPreferenceRows) {
        [void]$body.Add("$($g.AppPath) | $($g.Value) | $($g.Source)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Compatibility Layers ==")
    foreach ($c in Get-AppCompatLayerRows) {
        [void]$body.Add("$($c.AppPath) | $($c.Flags) | $($c.Source)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Security Products ==")
    foreach ($s in Get-SecurityProductRows) {
        [void]$body.Add("$($s.Type) | $($s.DisplayName) | State=$($s.ProductState) | $($s.PathToSignedProductExe)")
    }
    [void]$body.Add("")
    [void]$body.Add("== Devices ==")
    foreach ($d in Get-DeviceRows) {
        [void]$body.Add("$($d.Name) | Status=$($d.Status) | Class=$($d.Class) | Manufacturer=$($d.Manufacturer)")
    }
    $body -join [Environment]::NewLine | Set-Content -LiteralPath $path -Encoding UTF8
    return $path
}

function New-StateSnapshot {
    param([string]$Label = 'manual')
    New-ToolDirectory
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $safeLabel = ConvertTo-SafeName -Text $Label
    $jsonPath = Join-Path $script:Config.SnapshotRoot "FH6_StateSnapshot_${stamp}_$safeLabel.json"
    $txtPath = Join-Path $script:Config.SnapshotRoot "FH6_StateSnapshot_${stamp}_$safeLabel.txt"
    $snapshot = [pscustomobject]@{
        GeneratedAt    = (Get-Date).ToString('o')
        Label          = $Label
        Status         = Get-StatusSummary
        Health         = @(Get-HealthRows)
        Inventory      = @(Get-FH6Inventory)
        CrashReports   = @(Get-CrashReportRows)
        CrashEvents    = @(Get-CrashEventRows)
        Conflicts      = @(Get-ConflictProcesses)
        SteamInstalls  = @(Get-SteamInstallInfo)
        SteamLogRows   = @(Get-SteamLogRows)
        XboxServices   = @(Get-XboxServiceRows)
        VisualCRedists = @(Get-VisualCRedistRows)
        MediaFoundation = Get-MediaFoundationStatus
        WERReports     = @(Get-WERReportRows)
        CrashAnalysis  = Get-CrashSignatureAnalysis
        Recommendations = @(Get-ExpertRecommendationRows)
        Timeline       = @(Get-EventTimelineRows)
        LatestCrashCorrelation = @(Get-CrashCorrelationRows -Minutes 10)
        StartupPrograms = @(Get-StartupProgramRows)
        ProcessMitigations = @(Get-ProcessMitigationRows)
        DriverInventory = @(Get-DriverInventoryRows)
        InstallAudit   = @(Get-InstallAuditRows)
        TelemetryPreflight = Test-TelemetryPortAvailability -Port 5606
        WindowsGamingSettings = @(Get-WindowsGamingSettingRows)
        PowerThermal = @(Get-PowerThermalRows)
        XboxAppPackages = @(Get-XboxAppPackageRows)
        PathPermissions = @(Get-PathPermissionRows)
        BackupIntegrity = @(Get-BackupIntegrityRows)
        ReliabilityRecords = @(Get-ReliabilityRecordRows)
        DisplayTopology = @(Get-DisplayTopologyRows)
        GraphicsPreferences = @(Get-GraphicsPreferenceRows)
        CompatibilityLayers = @(Get-AppCompatLayerRows)
        SecurityProducts = @(Get-SecurityProductRows)
        ToolSafetyAudit = @(Get-ToolSafetyAuditRows)
        OfficialReferences = @(Get-OfficialReferenceRows)
        ToolFiles = @(Get-ToolFileRows)
        Devices        = @(Get-DeviceRows)
    }
    $snapshot | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $jsonPath -Encoding UTF8

    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add("FH6 Companion Doctor State Snapshot")
    [void]$lines.Add("Generated: $(Get-Date)")
    [void]$lines.Add("Label: $Label")
    [void]$lines.Add("")
    [void]$lines.Add("== Status ==")
    [void]$lines.Add($snapshot.Status)
    [void]$lines.Add("")
    [void]$lines.Add("== Health Warnings ==")
    foreach ($h in $snapshot.Health | Where-Object { $_.Status -ne 'OK' }) {
        [void]$lines.Add("[$($h.Status)] $($h.Area) / $($h.Check): $($h.Detail)")
        [void]$lines.Add("  $($h.Recommendation)")
    }
    [void]$lines.Add("")
    [void]$lines.Add("== Latest Crashes ==")
    foreach ($e in $snapshot.CrashEvents | Select-Object -First 10) {
        [void]$lines.Add("$($e.Time) $($e.EventName) $($e.Code) module=$($e.Module)")
    }
    [void]$lines.Add("")
    [void]$lines.Add("== Top Recommendations ==")
    foreach ($r in $snapshot.Recommendations | Sort-Object Priority | Select-Object -First 8) {
        [void]$lines.Add("[P$($r.Priority)] $($r.Area): $($r.Finding)")
        [void]$lines.Add("  $($r.Action)")
    }
    [void]$lines.Add("")
    [void]$lines.Add("== Conflicts ==")
    foreach ($c in $snapshot.Conflicts) {
        [void]$lines.Add("$($c.ProcessName) pid=$($c.Id) $($c.Path)")
    }
    [void]$lines.Add("")
    [void]$lines.Add("JSON: $jsonPath")
    $lines -join [Environment]::NewLine | Set-Content -LiteralPath $txtPath -Encoding UTF8
    return [pscustomobject]@{ Json = $jsonPath; Text = $txtPath }
}

function Get-StateSnapshotFiles {
    New-ToolDirectory
    @(Get-ChildItem -LiteralPath $script:Config.SnapshotRoot -File -Filter 'FH6_StateSnapshot_*.json' -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending)
}

function Compare-LatestStateSnapshots {
    $files = @(Get-StateSnapshotFiles | Select-Object -First 2)
    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add('FH6 State Snapshot Diff')
    [void]$lines.Add('=======================')
    if ($files.Count -lt 2) {
        [void]$lines.Add('Need at least two JSON snapshots. Use State Snapshot before and after a launch/crash attempt.')
        return ($lines -join [Environment]::NewLine)
    }

    $new = Get-Content -LiteralPath $files[0].FullName -Raw | ConvertFrom-Json
    $old = Get-Content -LiteralPath $files[1].FullName -Raw | ConvertFrom-Json
    [void]$lines.Add("New: $($files[0].Name) generated=$($new.GeneratedAt) label=$($new.Label)")
    [void]$lines.Add("Old: $($files[1].Name) generated=$($old.GeneratedAt) label=$($old.Label)")
    [void]$lines.Add('')

    function Count-ByCategory($items) {
        $map = @{}
        foreach ($g in @($items | Group-Object Category)) { $map[$g.Name] = $g.Count }
        return $map
    }
    $newInv = Count-ByCategory $new.Inventory
    $oldInv = Count-ByCategory $old.Inventory
    $allCategories = @($newInv.Keys + $oldInv.Keys | Sort-Object -Unique)
    [void]$lines.Add('Inventory category counts:')
    foreach ($cat in $allCategories) {
        $n = if ($newInv.ContainsKey($cat)) { $newInv[$cat] } else { 0 }
        $o = if ($oldInv.ContainsKey($cat)) { $oldInv[$cat] } else { 0 }
        $delta = $n - $o
        [void]$lines.Add("  $cat old=$o new=$n delta=$delta")
    }
    [void]$lines.Add('')

    $newCrash = @($new.CrashEvents)
    $oldCrash = @($old.CrashEvents)
    [void]$lines.Add("Crash event counts: old=$($oldCrash.Count) new=$($newCrash.Count) delta=$($newCrash.Count - $oldCrash.Count)")
    if ($newCrash.Count -gt 0) {
        [void]$lines.Add("Newest crash now: $($newCrash[0].Time) $($newCrash[0].EventName) $($newCrash[0].Code) module=$($newCrash[0].Module)")
    }
    if ($oldCrash.Count -gt 0) {
        [void]$lines.Add("Newest crash before: $($oldCrash[0].Time) $($oldCrash[0].EventName) $($oldCrash[0].Code) module=$($oldCrash[0].Module)")
    }
    [void]$lines.Add('')

    $newConflicts = @($new.Conflicts | ForEach-Object { "$($_.ProcessName):$($_.Id)" })
    $oldConflicts = @($old.Conflicts | ForEach-Object { "$($_.ProcessName):$($_.Id)" })
    $addedConflicts = @($newConflicts | Where-Object { $oldConflicts -notcontains $_ })
    $removedConflicts = @($oldConflicts | Where-Object { $newConflicts -notcontains $_ })
    [void]$lines.Add('Conflict process changes:')
    [void]$lines.Add("  Added: $(if ($addedConflicts.Count) { $addedConflicts -join ', ' } else { 'none' })")
    [void]$lines.Add("  Removed: $(if ($removedConflicts.Count) { $removedConflicts -join ', ' } else { 'none' })")
    [void]$lines.Add('')

    $newHealthWarn = @($new.Health | Where-Object { $_.Status -ne 'OK' } | ForEach-Object { "$($_.Area)/$($_.Check):$($_.Status):$($_.Detail)" })
    $oldHealthWarn = @($old.Health | Where-Object { $_.Status -ne 'OK' } | ForEach-Object { "$($_.Area)/$($_.Check):$($_.Status):$($_.Detail)" })
    $addedHealth = @($newHealthWarn | Where-Object { $oldHealthWarn -notcontains $_ })
    $removedHealth = @($oldHealthWarn | Where-Object { $newHealthWarn -notcontains $_ })
    [void]$lines.Add('Health warning changes:')
    [void]$lines.Add("  Added: $(if ($addedHealth.Count) { $addedHealth -join '; ' } else { 'none' })")
    [void]$lines.Add("  Removed: $(if ($removedHealth.Count) { $removedHealth -join '; ' } else { 'none' })")
    [void]$lines.Add('')

    [void]$lines.Add("Steam log match counts: old=$(@($old.SteamLogRows).Count) new=$(@($new.SteamLogRows).Count)")
    return ($lines -join [Environment]::NewLine)
}

function New-SupportPackage {
    param([scriptblock]$Log = { param($m) Write-Host $m })
    New-ToolDirectory
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $stage = Join-Path $env:TEMP "FH6_CompanionDoctor_Support_$stamp"
    $zip = Join-Path $script:Config.PackageRoot "FH6_CompanionDoctor_Support_$stamp.zip"
    New-Item -ItemType Directory -Path $stage -Force | Out-Null
    try {
        & $Log 'Collecting text report...'
        $report = Export-FH6Report -Records @(Get-FH6Inventory)
        Copy-Item -LiteralPath $report -Destination (Join-Path $stage (Split-Path $report -Leaf)) -Force

        & $Log 'Collecting dxdiag...'
        $dx = Join-Path $stage 'dxdiag.txt'
        try {
            Start-Process -FilePath 'dxdiag.exe' -ArgumentList @('/t', "`"$dx`"") -Wait -WindowStyle Hidden
        }
        catch {
            "dxdiag failed: $($_.Exception.Message)" | Set-Content -LiteralPath $dx -Encoding UTF8
        }

        & $Log 'Collecting crash events...'
        Get-CrashEventRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'fh6-crash-events.json') -Encoding UTF8
        Get-CrashReportRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'fh6-crash-reports.json') -Encoding UTF8
        Get-HealthRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'health.json') -Encoding UTF8
        Get-DeviceRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'devices.json') -Encoding UTF8
        Get-FH6Inventory | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'inventory.json') -Encoding UTF8
        Get-SteamLogRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'steam-log-matches.json') -Encoding UTF8
        Get-ConflictProcesses | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'conflict-processes.json') -Encoding UTF8
        Get-XboxServiceRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'xbox-services.json') -Encoding UTF8
        Get-VisualCRedistRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'visual-c-redists.json') -Encoding UTF8
        Get-MediaFoundationStatus | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'media-foundation.json') -Encoding UTF8
        Get-WERReportRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'wer-reports.json') -Encoding UTF8
        Get-CrashSignatureAnalysis | Set-Content -LiteralPath (Join-Path $stage 'crash-signature-analysis.txt') -Encoding UTF8
        Get-ExpertRecommendationRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'expert-recommendations.json') -Encoding UTF8
        Get-ExpertRecommendationSummary | Set-Content -LiteralPath (Join-Path $stage 'expert-recommendations.txt') -Encoding UTF8
        Get-EventTimelineRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'event-timeline.json') -Encoding UTF8
        Get-EventTimelineSummary | Set-Content -LiteralPath (Join-Path $stage 'event-timeline.txt') -Encoding UTF8
        Get-StartupProgramRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'startup-programs.json') -Encoding UTF8
        Get-ProcessMitigationRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'process-mitigations.json') -Encoding UTF8
        Get-DriverInventoryRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'driver-inventory.json') -Encoding UTF8
        Get-InstallAuditRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'read-only-install-audit.json') -Encoding UTF8
        Get-CrashCorrelationRows -Minutes 10 | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'latest-crash-correlation.json') -Encoding UTF8
        Get-CrashCorrelationSummary -Minutes 10 | Set-Content -LiteralPath (Join-Path $stage 'latest-crash-correlation.txt') -Encoding UTF8
        Get-TelemetryPreflightSummary -Port 5606 | Set-Content -LiteralPath (Join-Path $stage 'telemetry-port-preflight.txt') -Encoding UTF8
        Get-WindowsGamingSettingRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'windows-gaming-settings.json') -Encoding UTF8
        Get-PowerThermalRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'power-thermal.json') -Encoding UTF8
        Get-XboxAppPackageRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'xbox-app-packages.json') -Encoding UTF8
        Get-PathPermissionRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'path-permissions.json') -Encoding UTF8
        Get-BackupIntegrityRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'backup-integrity.json') -Encoding UTF8
        Get-ReliabilityRecordRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'reliability-records.json') -Encoding UTF8
        Get-DisplayTopologyRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'display-topology.json') -Encoding UTF8
        Get-GraphicsPreferenceRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'graphics-preferences.json') -Encoding UTF8
        Get-AppCompatLayerRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'compatibility-layers.json') -Encoding UTF8
        Get-SecurityProductRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'security-products.json') -Encoding UTF8
        Invoke-CompanionSelfTest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'tool-self-test.json') -Encoding UTF8
        Get-ToolSafetyAuditRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'tool-safety-audit.json') -Encoding UTF8
        Get-OfficialReferenceRows | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $stage 'official-references.json') -Encoding UTF8
        $manifestPath = Write-ToolManifest
        Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $stage 'FH6_CompanionDoctor_Manifest.json') -Force

        $snapshot = New-StateSnapshot -Label 'support-package'
        Copy-Item -LiteralPath $snapshot.Json -Destination (Join-Path $stage 'state-snapshot.json') -Force
        Copy-Item -LiteralPath $snapshot.Text -Destination (Join-Path $stage 'state-snapshot.txt') -Force

        if (Test-Path -LiteralPath $script:Config.LocalRoot) {
            $destReports = Join-Path $stage 'FH6-local-crash-reports'
            New-Item -ItemType Directory -Path $destReports -Force | Out-Null
            Get-ChildItem -LiteralPath $script:Config.LocalRoot -Force -Directory -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -match '^report_\d{4}_\d{2}_\d{2}_' } |
                Select-Object -First 20 |
                ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $destReports $_.Name) -Recurse -Force -ErrorAction SilentlyContinue }
        }

        if ($script:RunLogPath -and (Test-Path -LiteralPath $script:RunLogPath)) {
            Copy-Item -LiteralPath $script:RunLogPath -Destination (Join-Path $stage 'tool-run.log') -Force
        }

        $content = @(Get-ChildItem -LiteralPath $stage -Force | Select-Object -ExpandProperty FullName)
        Compress-Archive -LiteralPath $content -DestinationPath $zip -Force
        & $Log "Support package written: $zip"
        return $zip
    }
    finally {
        if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue }
    }
}

function Convert-BytesToTelemetryPacket {
    param([Parameter(Mandatory)][byte[]]$Bytes)
    if ($Bytes.Length -lt 324) { return $null }
    function I32($o) { [BitConverter]::ToInt32($Bytes, $o) }
    function U32($o) { [BitConverter]::ToUInt32($Bytes, $o) }
    function F32($o) { [BitConverter]::ToSingle($Bytes, $o) }
    function U16($o) { [BitConverter]::ToUInt16($Bytes, $o) }
    function U8($o) { [int]$Bytes[$o] }
    function S8($o) {
        $v = [int]$Bytes[$o]
        if ($v -gt 127) { return ($v - 256) }
        return $v
    }
    $speedMps = F32 256
    [pscustomobject]@{
        ReceivedAt        = Get-Date
        IsRaceOn          = I32 0
        TimestampMS       = U32 4
        EngineMaxRpm      = F32 8
        EngineIdleRpm     = F32 12
        CurrentEngineRpm  = F32 16
        VelocityX         = F32 32
        VelocityY         = F32 36
        VelocityZ         = F32 40
        Yaw               = F32 56
        Pitch             = F32 60
        Roll              = F32 64
        TireSlipFL        = F32 84
        TireSlipFR        = F32 88
        TireSlipRL        = F32 92
        TireSlipRR        = F32 96
        CarOrdinal        = I32 212
        CarClass          = I32 216
        PI                = I32 220
        DrivetrainType    = I32 224
        NumCylinders      = I32 228
        CarGroup          = U32 232
        PositionX         = F32 244
        PositionY         = F32 248
        PositionZ         = F32 252
        SpeedMps          = $speedMps
        SpeedMph          = $speedMps * 2.23693629
        PowerWatts        = F32 260
        TorqueNm          = F32 264
        TireTempFL        = F32 268
        TireTempFR        = F32 272
        TireTempRL        = F32 276
        TireTempRR        = F32 280
        BoostPsi          = F32 284
        Fuel              = F32 288
        DistanceMeters    = F32 292
        BestLap           = F32 296
        LastLap           = F32 300
        CurrentLap        = F32 304
        RaceTime          = F32 308
        LapNumber         = U16 312
        RacePosition      = U8 314
        Accel             = U8 315
        Brake             = U8 316
        Clutch            = U8 317
        HandBrake         = U8 318
        Gear              = U8 319
        Steer             = S8 320
    }
}

function Write-TelemetryCsv {
    param([Parameter(Mandatory)][object]$Packet)
    if (-not $script:TelemetryCsvPath) { return }
    if (-not (Test-Path -LiteralPath $script:TelemetryCsvPath)) {
        'ReceivedAt,TimestampMS,IsRaceOn,SpeedMph,RPM,Gear,Accel,Brake,Steer,CarOrdinal,CarClass,PI,BoostPsi,Fuel,LapNumber,RacePosition,BestLap,LastLap,CurrentLap,RaceTime,PositionX,PositionY,PositionZ' |
            Set-Content -LiteralPath $script:TelemetryCsvPath -Encoding UTF8
    }
    $line = '{0},{1},{2},{3:N2},{4:N0},{5},{6},{7},{8},{9},{10},{11},{12:N2},{13:N3},{14},{15},{16:N3},{17:N3},{18:N3},{19:N3},{20:N2},{21:N2},{22:N2}' -f `
        $Packet.ReceivedAt.ToString('o'), $Packet.TimestampMS, $Packet.IsRaceOn, $Packet.SpeedMph, $Packet.CurrentEngineRpm, $Packet.Gear, $Packet.Accel, $Packet.Brake, $Packet.Steer, $Packet.CarOrdinal, $Packet.CarClass, $Packet.PI, $Packet.BoostPsi, $Packet.Fuel, $Packet.LapNumber, $Packet.RacePosition, $Packet.BestLap, $Packet.LastLap, $Packet.CurrentLap, $Packet.RaceTime, $Packet.PositionX, $Packet.PositionY, $Packet.PositionZ
    Add-Content -LiteralPath $script:TelemetryCsvPath -Value $line -Encoding UTF8
}

function Start-NoGuiScan {
    New-ToolDirectory
    Write-Output (Get-StatusSummary)
    Write-Output ''
    Write-Output 'Health:'
    Get-HealthRows | Format-Table Area, Check, Status, Detail -AutoSize
    Write-Output ''
    Write-Output 'Inventory:'
    Get-FH6Inventory | Sort-Object Category, Path | Format-Table Category, Exists, Cleanable, SizeMB, Items, LastWriteTime, Path -AutoSize
    Write-Output ''
    Write-Output 'Crash summary:'
    Write-Output (Get-CrashSummary)
    Write-Output ''
    Write-Output 'Crash signature analysis:'
    Write-Output (Get-CrashSignatureAnalysis)
    Write-Output ''
    Write-Output 'Expert recommendations:'
    Write-Output (Get-ExpertRecommendationSummary)
    Write-Output ''
    Write-Output 'Event timeline:'
    Write-Output (Get-EventTimelineSummary)
    Write-Output ''
    Write-Output 'Latest crash correlation:'
    Write-Output (Get-CrashCorrelationSummary -Minutes 10)
    Write-Output ''
    Write-Output 'Conflicts:'
    Write-Output (Get-ConflictSummary)
    Write-Output ''
    Write-Output 'Steam logs:'
    Write-Output (Get-SteamLogSummary)
    Write-Output ''
    Write-Output 'Read-only install audit:'
    Get-InstallAuditRows | Format-Table Check, Status, Value, Path -AutoSize
    Write-Output ''
    Write-Output 'Telemetry port preflight:'
    Write-Output (Get-TelemetryPreflightSummary -Port 5606)
    Write-Output ''
    Write-Output 'Windows gaming settings:'
    Get-WindowsGamingSettingRows | Format-Table Area, Name, Value, Interpretation -AutoSize
    Write-Output ''
    Write-Output 'Path permissions:'
    Get-PathPermissionRows | Format-Table Status, Exists, Path, Detail -AutoSize
    Write-Output ''
    Write-Output 'Backup integrity:'
    Get-BackupIntegrityRows | Format-Table Status, Name, Entries, SizeMB, Detail -AutoSize
    Write-Output ''
    Write-Output 'Reliability records:'
    Get-ReliabilityRecordRows | Format-Table TimeGenerated, SourceName, ProductName, EventId -AutoSize
    Write-Output ''
    Write-Output 'Display topology:'
    Get-DisplayTopologyRows | Format-Table Type, Name, Detail, Driver, Status -AutoSize
    Write-Output ''
    Write-Output 'Compatibility layers:'
    Get-AppCompatLayerRows | Format-Table AppPath, Flags, Source -AutoSize
    Write-Output ''
    Write-Output 'Security products:'
    Get-SecurityProductRows | Format-Table Type, DisplayName, ProductState -AutoSize
}

if ($NoGui) {
    Start-NoGuiScan
    if ($SelfTest) {
        Write-Output ''
        Write-Output 'Self-test:'
        Invoke-CompanionSelfTest | Format-Table Test, Status, Detail -AutoSize
        Write-Output ''
        Write-Output 'Safety audit:'
        Get-ToolSafetyAuditRows | Format-Table Check, Status, Detail -AutoSize
    }
    if ($Snapshot) {
        $snap = New-StateSnapshot -Label 'nogui'
        Write-Output ''
        Write-Output "Snapshot text: $($snap.Text)"
        Write-Output "Snapshot json: $($snap.Json)"
    }
    if ($Diff) {
        Write-Output ''
        Write-Output (Compare-LatestStateSnapshots)
    }
    if ($Manifest) {
        Write-Output ''
        Write-Output "Manifest: $(Write-ToolManifest)"
    }
    if ($PortableBundle) {
        Write-Output ''
        Write-Output "Portable bundle: $(New-PortableToolBundle)"
    }
    return
}

if ([System.Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA' -and $PSCommandPath) {
    $exe = (Get-Process -Id $PID).Path
    Start-Process -FilePath $exe -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-File', "`"$PSCommandPath`"")
    return
}

New-ToolDirectory
$script:Settings = Read-CompanionSettings
$script:RunLogPath = Join-Path $script:Config.LogRoot ("FH6_CompanionDoctor_Run_{0}.log" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
"FH6 Companion Doctor started: $(Get-Date)" | Set-Content -LiteralPath $script:RunLogPath -Encoding UTF8

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$form = New-Object System.Windows.Forms.Form
$form.Text = 'FH6 Companion Doctor v4.0'
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(1360, 920)
$form.MinimumSize = New-Object System.Drawing.Size(1180, 800)

$tabs = New-Object System.Windows.Forms.TabControl
$tabs.Location = New-Object System.Drawing.Point(10, 10)
$tabs.Size = New-Object System.Drawing.Size(1320, 650)
$form.Controls.Add($tabs)

$tabHealth = New-Object System.Windows.Forms.TabPage
$tabHealth.Text = 'Health'
$tabs.Controls.Add($tabHealth)

$tabSaves = New-Object System.Windows.Forms.TabPage
$tabSaves.Text = 'Saves'
$tabs.Controls.Add($tabSaves)

$tabCrash = New-Object System.Windows.Forms.TabPage
$tabCrash.Text = 'Crash Lab'
$tabs.Controls.Add($tabCrash)

$tabTelemetry = New-Object System.Windows.Forms.TabPage
$tabTelemetry.Text = 'Telemetry'
$tabs.Controls.Add($tabTelemetry)

$tabDevices = New-Object System.Windows.Forms.TabPage
$tabDevices.Text = 'Devices'
$tabs.Controls.Add($tabDevices)

$tabLaunch = New-Object System.Windows.Forms.TabPage
$tabLaunch.Text = 'Launch'
$tabs.Controls.Add($tabLaunch)

$tabReports = New-Object System.Windows.Forms.TabPage
$tabReports.Text = 'Reports'
$tabs.Controls.Add($tabReports)

$txtLog = New-Object System.Windows.Forms.TextBox
$txtLog.Location = New-Object System.Drawing.Point(10, 670)
$txtLog.Size = New-Object System.Drawing.Size(1320, 200)
$txtLog.Multiline = $true
$txtLog.ScrollBars = 'Vertical'
$txtLog.ReadOnly = $true
$txtLog.Font = New-Object System.Drawing.Font('Consolas', 9)
$form.Controls.Add($txtLog)

function Add-Log {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $Message
    $txtLog.AppendText($line + [Environment]::NewLine)
    if ($script:RunLogPath) { Add-Content -LiteralPath $script:RunLogPath -Value $line -Encoding UTF8 -ErrorAction SilentlyContinue }
}

function New-Button {
    param([string]$Text, [int]$X, [int]$Y, [int]$W = 120, [int]$H = 30)
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $Text
    $b.Location = New-Object System.Drawing.Point($X, $Y)
    $b.Size = New-Object System.Drawing.Size($W, $H)
    return $b
}

function New-Grid {
    param([int]$X, [int]$Y, [int]$W, [int]$H)
    $g = New-Object System.Windows.Forms.DataGridView
    $g.Location = New-Object System.Drawing.Point($X, $Y)
    $g.Size = New-Object System.Drawing.Size($W, $H)
    $g.AutoSizeColumnsMode = 'Fill'
    $g.SelectionMode = 'FullRowSelect'
    $g.MultiSelect = $false
    $g.ReadOnly = $true
    $g.AllowUserToAddRows = $false
    $g.AllowUserToDeleteRows = $false
    return $g
}

function Show-TextWindow {
    param([string]$Title, [string]$Text)
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = $Title
    $dialog.StartPosition = 'CenterParent'
    $dialog.Size = New-Object System.Drawing.Size(980, 650)
    $box = New-Object System.Windows.Forms.TextBox
    $box.Multiline = $true
    $box.ReadOnly = $true
    $box.ScrollBars = 'Both'
    $box.WordWrap = $false
    $box.Dock = 'Fill'
    $box.Font = New-Object System.Drawing.Font('Consolas', 9)
    $box.Text = $Text
    $dialog.Controls.Add($box)
    [void]$dialog.ShowDialog($form)
}

# Health tab
$gridHealth = New-Grid 10 50 1280 520
$tabHealth.Controls.Add($gridHealth)
$btnHealthScan = New-Button 'Run Health Scan' 10 10 140
$tabHealth.Controls.Add($btnHealthScan)
$btnHealthReport = New-Button 'Export Report' 160 10 120
$tabHealth.Controls.Add($btnHealthReport)
$btnHealthSupport = New-Button 'Support Package' 290 10 140
$tabHealth.Controls.Add($btnHealthSupport)
$btnOpenLogs = New-Button 'Open Logs' 440 10 110
$tabHealth.Controls.Add($btnOpenLogs)
$btnShowConflicts = New-Button 'Show Conflicts' 560 10 130
$tabHealth.Controls.Add($btnShowConflicts)
$btnSteamLogs = New-Button 'Steam Logs' 700 10 110
$tabHealth.Controls.Add($btnSteamLogs)
$btnServiceDetails = New-Button 'Services' 820 10 100
$tabHealth.Controls.Add($btnServiceDetails)
$btnRuntimeDetails = New-Button 'Runtimes' 930 10 100
$tabHealth.Controls.Add($btnRuntimeDetails)
$btnRunbook = New-Button 'Runbook' 1040 10 100
$tabHealth.Controls.Add($btnRunbook)
$btnStartup = New-Button 'Startup' 1150 10 100
$tabHealth.Controls.Add($btnStartup)
$btnPlatformAudit = New-Button 'Platform Audit' 10 585 130
$tabHealth.Controls.Add($btnPlatformAudit)
$btnPermissionAudit = New-Button 'Permissions' 150 585 110
$tabHealth.Controls.Add($btnPermissionAudit)
$btnBackupAudit = New-Button 'Backup Audit' 270 585 120
$tabHealth.Controls.Add($btnBackupAudit)
$btnReliability = New-Button 'Reliability' 400 585 110
$tabHealth.Controls.Add($btnReliability)
$btnDisplayAudit = New-Button 'Display/GPU' 520 585 110
$tabHealth.Controls.Add($btnDisplayAudit)
$btnCompatAudit = New-Button 'Compat/GPU Prefs' 640 585 145
$tabHealth.Controls.Add($btnCompatAudit)
$btnSecurityAudit = New-Button 'Security' 795 585 100
$tabHealth.Controls.Add($btnSecurityAudit)

# Saves tab
$listSaves = New-Object System.Windows.Forms.ListView
$listSaves.Location = New-Object System.Drawing.Point(10, 50)
$listSaves.Size = New-Object System.Drawing.Size(1280, 460)
$listSaves.View = [System.Windows.Forms.View]::Details
$listSaves.CheckBoxes = $true
$listSaves.FullRowSelect = $true
$listSaves.GridLines = $true
[void]$listSaves.Columns.Add('Category', 105)
[void]$listSaves.Columns.Add('Exists', 55)
[void]$listSaves.Columns.Add('Size MB', 70)
[void]$listSaves.Columns.Add('Items', 60)
[void]$listSaves.Columns.Add('Modified', 135)
[void]$listSaves.Columns.Add('Risk', 90)
[void]$listSaves.Columns.Add('Path', 810)
$tabSaves.Controls.Add($listSaves)
$chkBackup = New-Object System.Windows.Forms.CheckBox
$chkBackup.Text = 'Back up before delete/rename'
$chkBackup.Checked = $true
$chkBackup.AutoSize = $true
$chkBackup.Location = New-Object System.Drawing.Point(10, 15)
$tabSaves.Controls.Add($chkBackup)
$chkDryRun = New-Object System.Windows.Forms.CheckBox
$chkDryRun.Text = 'Dry run'
$chkDryRun.AutoSize = $true
$chkDryRun.Location = New-Object System.Drawing.Point(230, 15)
$tabSaves.Controls.Add($chkDryRun)
$chkStopGame = New-Object System.Windows.Forms.CheckBox
$chkStopGame.Text = 'Stop FH6 if running'
$chkStopGame.AutoSize = $true
$chkStopGame.Location = New-Object System.Drawing.Point(320, 15)
$tabSaves.Controls.Add($chkStopGame)
$btnSaveScan = New-Button 'Scan' 10 525 90
$btnSelectSaves = New-Button 'Select Saves' 105 525 110
$btnSelectDeep = New-Button 'Select Save+Cache' 220 525 140
$btnClearSel = New-Button 'Clear Selection' 365 525 125
$btnBackup = New-Button 'Backup' 500 525 95
$btnRename = New-Button 'Rename' 600 525 95
$btnDelete = New-Button 'Delete' 700 525 95
$btnFresh = New-Button 'Fresh Start' 800 525 105
$btnDeepFresh = New-Button 'Deep Fresh' 910 525 105
$btnRestore = New-Button 'Restore Backup' 1020 525 125
foreach ($b in @($btnSaveScan,$btnSelectSaves,$btnSelectDeep,$btnClearSel,$btnBackup,$btnRename,$btnDelete,$btnFresh,$btnDeepFresh,$btnRestore)) { $tabSaves.Controls.Add($b) }
$lblMonitor = New-Object System.Windows.Forms.Label
$lblMonitor.Text = 'Monitor:'
$lblMonitor.Location = New-Object System.Drawing.Point(10, 588)
$lblMonitor.Size = New-Object System.Drawing.Size(65, 22)
$tabSaves.Controls.Add($lblMonitor)
$cmbMonitorMode = New-Object System.Windows.Forms.ComboBox
$cmbMonitorMode.DropDownStyle = 'DropDownList'
[void]$cmbMonitorMode.Items.Add('Saves only')
[void]$cmbMonitorMode.Items.Add('Saves + cache')
$cmbMonitorMode.SelectedIndex = 0
$cmbMonitorMode.Location = New-Object System.Drawing.Point(75, 584)
$cmbMonitorMode.Size = New-Object System.Drawing.Size(130, 24)
$tabSaves.Controls.Add($cmbMonitorMode)
$numMonitorSec = New-Object System.Windows.Forms.NumericUpDown
$numMonitorSec.Minimum = 10
$numMonitorSec.Maximum = 600
$numMonitorSec.Value = 30
$numMonitorSec.Location = New-Object System.Drawing.Point(215, 584)
$numMonitorSec.Size = New-Object System.Drawing.Size(70, 24)
$tabSaves.Controls.Add($numMonitorSec)
$btnMonitor = New-Button 'Start Monitor' 295 580 125
$tabSaves.Controls.Add($btnMonitor)
$lblMonitorStatus = New-Object System.Windows.Forms.Label
$lblMonitorStatus.Text = 'Idle'
$lblMonitorStatus.Location = New-Object System.Drawing.Point(430, 588)
$lblMonitorStatus.Size = New-Object System.Drawing.Size(800, 22)
$tabSaves.Controls.Add($lblMonitorStatus)

# Crash tab
$gridCrashReports = New-Grid 10 45 620 500
$gridCrashEvents = New-Grid 640 45 650 500
$tabCrash.Controls.Add($gridCrashReports)
$tabCrash.Controls.Add($gridCrashEvents)
$btnCrashRefresh = New-Button 'Refresh Crashes' 10 10 140
$btnCrashSummary = New-Button 'Show Summary' 160 10 120
$btnCrashAnalysis = New-Button 'Analyze' 290 10 100
$btnWerReports = New-Button 'WER Reports' 400 10 110
$btnTimeline = New-Button 'Timeline' 520 10 100
$btnCorrelation = New-Button 'Correlate' 630 10 100
$btnClearCrashReports = New-Button 'Clear Reports' 740 10 120
$tabCrash.Controls.Add($btnCrashRefresh)
$tabCrash.Controls.Add($btnCrashSummary)
$tabCrash.Controls.Add($btnCrashAnalysis)
$tabCrash.Controls.Add($btnWerReports)
$tabCrash.Controls.Add($btnTimeline)
$tabCrash.Controls.Add($btnCorrelation)
$tabCrash.Controls.Add($btnClearCrashReports)

# Telemetry tab
$lblTelem = New-Object System.Windows.Forms.Label
$lblTelem.Text = 'Configure FH6: Settings > HUD and Gameplay > Data Out On, IP 127.0.0.1, Port:'
$lblTelem.Location = New-Object System.Drawing.Point(10, 15)
$lblTelem.Size = New-Object System.Drawing.Size(560, 24)
$tabTelemetry.Controls.Add($lblTelem)
$numPort = New-Object System.Windows.Forms.NumericUpDown
$numPort.Minimum = 1024
$numPort.Maximum = 65535
$numPort.Value = 5606
$numPort.Location = New-Object System.Drawing.Point(570, 12)
$numPort.Size = New-Object System.Drawing.Size(90, 24)
$tabTelemetry.Controls.Add($numPort)
$chkTelemCsv = New-Object System.Windows.Forms.CheckBox
$chkTelemCsv.Text = 'Log CSV'
$chkTelemCsv.AutoSize = $true
$chkTelemCsv.Checked = $true
$chkTelemCsv.Location = New-Object System.Drawing.Point(675, 15)
$tabTelemetry.Controls.Add($chkTelemCsv)
$btnTelemStart = New-Button 'Start Listener' 760 10 120
$btnTelemStop = New-Button 'Stop' 885 10 90
$btnOpenTelemetry = New-Button 'Open Telemetry Logs' 985 10 150
$btnTelemPreflight = New-Button 'Port Preflight' 1145 10 120
$tabTelemetry.Controls.Add($btnTelemStart)
$tabTelemetry.Controls.Add($btnTelemStop)
$tabTelemetry.Controls.Add($btnOpenTelemetry)
$tabTelemetry.Controls.Add($btnTelemPreflight)
$txtTelemetry = New-Object System.Windows.Forms.TextBox
$txtTelemetry.Location = New-Object System.Drawing.Point(10, 50)
$txtTelemetry.Size = New-Object System.Drawing.Size(1280, 560)
$txtTelemetry.Multiline = $true
$txtTelemetry.ReadOnly = $true
$txtTelemetry.ScrollBars = 'Vertical'
$txtTelemetry.Font = New-Object System.Drawing.Font('Consolas', 12)
$tabTelemetry.Controls.Add($txtTelemetry)

# Devices tab
$gridDevices = New-Grid 10 45 1280 540
$tabDevices.Controls.Add($gridDevices)
$btnDevicesRefresh = New-Button 'Scan Devices' 10 10 120
$btnDeviceAdvice = New-Button 'Wheel Advice' 140 10 120
$btnDriverInventory = New-Button 'Driver Inventory' 270 10 135
$tabDevices.Controls.Add($btnDevicesRefresh)
$tabDevices.Controls.Add($btnDeviceAdvice)
$tabDevices.Controls.Add($btnDriverInventory)

# Launch tab
$txtPreflight = New-Object System.Windows.Forms.TextBox
$txtPreflight.Location = New-Object System.Drawing.Point(10, 50)
$txtPreflight.Size = New-Object System.Drawing.Size(1280, 520)
$txtPreflight.Multiline = $true
$txtPreflight.ReadOnly = $true
$txtPreflight.ScrollBars = 'Vertical'
$txtPreflight.Font = New-Object System.Drawing.Font('Consolas', 9)
$tabLaunch.Controls.Add($txtPreflight)
$btnPreflight = New-Button 'Run Preflight' 10 10 120
$btnLaunchSteam = New-Button 'Launch FH6' 140 10 110
$btnPreflightLaunch = New-Button 'Preflight + Launch' 260 10 145
$btnSnapshotBefore = New-Button 'Snapshot' 415 10 100
$btnSteamCloudSteps = New-Button 'Steam Cloud Steps' 525 10 150
$btnOpenSteamInstall = New-Button 'Open Install Folder' 685 10 150
$btnInstallAudit = New-Button 'Install Audit' 845 10 120
$btnSessionLaunch = New-Button 'Session Launch' 975 10 130
$btnSessionFinish = New-Button 'Finish Session' 1115 10 130
foreach ($b in @($btnPreflight,$btnLaunchSteam,$btnPreflightLaunch,$btnSnapshotBefore,$btnSteamCloudSteps,$btnOpenSteamInstall,$btnInstallAudit,$btnSessionLaunch,$btnSessionFinish)) { $tabLaunch.Controls.Add($b) }

# Reports tab
$txtReports = New-Object System.Windows.Forms.TextBox
$txtReports.Location = New-Object System.Drawing.Point(10, 50)
$txtReports.Size = New-Object System.Drawing.Size(1280, 520)
$txtReports.Multiline = $true
$txtReports.ReadOnly = $true
$txtReports.ScrollBars = 'Vertical'
$txtReports.Font = New-Object System.Drawing.Font('Consolas', 9)
$tabReports.Controls.Add($txtReports)
$btnExportReport = New-Button 'Export Report' 10 10 120
$btnSupportPackage = New-Button 'Build Support Package' 140 10 170
$btnStateSnapshot = New-Button 'State Snapshot' 320 10 130
$btnSnapshotDiff = New-Button 'Snapshot Diff' 460 10 125
$btnRedactedReport = New-Button 'Redacted Summary' 595 10 145
$btnOpenReports = New-Button 'Open Reports' 750 10 120
$btnOpenPackages = New-Button 'Open Packages' 880 10 130
$btnOpenSnapshots = New-Button 'Open Snapshots' 1020 10 130
$btnOpenSessions = New-Button 'Open Sessions' 1160 10 120
foreach ($b in @($btnExportReport,$btnSupportPackage,$btnStateSnapshot,$btnSnapshotDiff,$btnRedactedReport,$btnOpenReports,$btnOpenPackages,$btnOpenSnapshots,$btnOpenSessions)) { $tabReports.Controls.Add($b) }
$btnSelfTest = New-Button 'Self-Test' 10 585 100
$btnSafetyAudit = New-Button 'Safety Audit' 120 585 120
$btnManifest = New-Button 'Manifest' 250 585 100
$btnOfficialRefs = New-Button 'Official Refs' 360 585 120
$btnPortableBundle = New-Button 'Portable Bundle' 490 585 145
$btnOpenBundles = New-Button 'Open Bundles' 645 585 120
foreach ($b in @($btnSelfTest,$btnSafetyAudit,$btnManifest,$btnOfficialRefs,$btnPortableBundle,$btnOpenBundles)) { $tabReports.Controls.Add($b) }

function Apply-CompanionSettingsToUi {
    try {
        $numPort.Value = [Math]::Min([Math]::Max([int]$script:Settings.TelemetryPort, [int]$numPort.Minimum), [int]$numPort.Maximum)
        $chkTelemCsv.Checked = [bool]$script:Settings.TelemetryCsv
        $chkBackup.Checked = [bool]$script:Settings.BackupByDefault
        $chkDryRun.Checked = [bool]$script:Settings.DryRunByDefault
        $chkStopGame.Checked = [bool]$script:Settings.StopGameByDefault
        $numMonitorSec.Value = [Math]::Min([Math]::Max([int]$script:Settings.MonitorSeconds, [int]$numMonitorSec.Minimum), [int]$numMonitorSec.Maximum)
        $modeIndex = $cmbMonitorMode.Items.IndexOf([string]$script:Settings.MonitorMode)
        if ($modeIndex -ge 0) { $cmbMonitorMode.SelectedIndex = $modeIndex }
        for ($i = 0; $i -lt $tabs.TabPages.Count; $i++) {
            if ($tabs.TabPages[$i].Text -eq [string]$script:Settings.LastTab) {
                $tabs.SelectedIndex = $i
                break
            }
        }
    }
    catch {
        Add-Log "Settings apply warning: $($_.Exception.Message)"
    }
}

function Save-CompanionSettingsFromUi {
    $settings = [pscustomobject]@{
        TelemetryPort     = [int]$numPort.Value
        TelemetryCsv      = [bool]$chkTelemCsv.Checked
        BackupByDefault   = [bool]$chkBackup.Checked
        DryRunByDefault   = [bool]$chkDryRun.Checked
        StopGameByDefault = [bool]$chkStopGame.Checked
        MonitorMode       = [string]$cmbMonitorMode.SelectedItem
        MonitorSeconds    = [int]$numMonitorSec.Value
        LastTab           = [string]$tabs.SelectedTab.Text
    }
    Write-CompanionSettings -Settings $settings
}

function Refresh-SaveInventory {
    $listSaves.Items.Clear()
    $script:ItemsById = @{}
    $script:Items = @(Get-FH6Inventory)
    foreach ($record in $script:Items | Sort-Object Category, Path) {
        $row = New-Object System.Windows.Forms.ListViewItem($record.Category)
        $row.Checked = [bool]($record.DefaultSelected -and $record.Exists -and $record.Cleanable)
        $row.Tag = $record.Id
        [void]$row.SubItems.Add([string]$record.Exists)
        [void]$row.SubItems.Add([string]$record.SizeMB)
        [void]$row.SubItems.Add([string]$record.Items)
        $modified = if ($record.LastWriteTime) { $record.LastWriteTime.ToString('yyyy-MM-dd HH:mm') } else { '' }
        [void]$row.SubItems.Add($modified)
        [void]$row.SubItems.Add($record.Risk)
        [void]$row.SubItems.Add($record.Path)
        if (-not $record.Cleanable) { $row.ForeColor = [System.Drawing.Color]::Gray; $row.Checked = $false }
        [void]$listSaves.Items.Add($row)
        $script:ItemsById[$record.Id] = $record
    }
    Add-Log "Save inventory refreshed: $($script:Items.Count) records."
}

function Get-SelectedSaveRecords {
    $selected = New-Object System.Collections.Generic.List[object]
    foreach ($row in $listSaves.Items) {
        if ($row.Checked -and $script:ItemsById.ContainsKey($row.Tag)) {
            $record = $script:ItemsById[$row.Tag]
            if ($record.Cleanable) { [void]$selected.Add($record) }
        }
    }
    return $selected.ToArray()
}

function Select-SaveCategories {
    param([string[]]$Categories)
    foreach ($row in $listSaves.Items) {
        if ($script:ItemsById.ContainsKey($row.Tag)) {
            $record = $script:ItemsById[$row.Tag]
            $row.Checked = ($record.Cleanable -and $record.Exists -and ($Categories -contains $record.Category))
        }
    }
}

function Invoke-SaveAction {
    param([string]$Action, [object[]]$Records)
    if ($Records.Count -eq 0) {
        [System.Windows.Forms.MessageBox]::Show('Nothing selected.', 'FH6 Companion Doctor', 'OK', 'Information') | Out-Null
        return
    }
    $preview = ($Records | Select-Object -First 8 | ForEach-Object { " - $($_.Path)" }) -join [Environment]::NewLine
    if ($Records.Count -gt 8) { $preview += [Environment]::NewLine + " - ...and $($Records.Count - 8) more" }
    $answer = [System.Windows.Forms.MessageBox]::Show("$Action $($Records.Count) item(s)?`n`n$preview`n`nSteam Cloud should be off before deleting FH6 saves.", "Confirm $Action", 'OKCancel', 'Warning')
    if ($answer -ne [System.Windows.Forms.DialogResult]::OK) { Add-Log "$Action cancelled."; return }
    try {
        Invoke-Preflight -StopGame $chkStopGame.Checked -Log ${function:Add-Log} | Out-Null
        if ($chkBackup.Checked -and -not $chkDryRun.Checked) { Backup-FH6Targets -Records $Records -Log ${function:Add-Log} | Out-Null }
        elseif ($chkBackup.Checked -and $chkDryRun.Checked) { Add-Log 'DRY RUN backup: would create a zip backup first.' }
        if ($Action -eq 'Rename') { Rename-FH6Targets -Records $Records -DryRun $chkDryRun.Checked -Log ${function:Add-Log} }
        elseif ($Action -eq 'Delete') { Remove-FH6Targets -Records $Records -DryRun $chkDryRun.Checked -Log ${function:Add-Log} }
        Refresh-SaveInventory
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, "$Action failed", 'OK', 'Error') | Out-Null
        Add-Log "$Action failed: $($_.Exception.Message)"
    }
}

function Refresh-Health {
    $gridHealth.DataSource = @(Get-HealthRows)
    Add-Log 'Health scan complete.'
}

function Refresh-Crashes {
    $gridCrashReports.DataSource = @(Get-CrashReportRows)
    $gridCrashEvents.DataSource = @(Get-CrashEventRows)
    Add-Log 'Crash Lab refreshed.'
}

function Refresh-Devices {
    $gridDevices.DataSource = @(Get-DeviceRows)
    Add-Log 'Device scan complete.'
}

function Get-PreflightText {
    $lines = New-Object System.Collections.Generic.List[string]
    [void]$lines.Add('== Preflight ==')
    [void]$lines.Add((Get-StatusSummary))
    [void]$lines.Add('')
    [void]$lines.Add('== Health Checks ==')
    foreach ($h in Get-HealthRows) { [void]$lines.Add("[$($h.Status)] $($h.Area) / $($h.Check): $($h.Detail)") }
    [void]$lines.Add('')
    [void]$lines.Add('== Conflict Processes ==')
    [void]$lines.Add((Get-ConflictSummary))
    [void]$lines.Add('')
    [void]$lines.Add('== Latest Crashes ==')
    [void]$lines.Add((Get-CrashSummary))
    return ($lines -join [Environment]::NewLine)
}

function Start-FH6LaunchSession {
    if ($script:SessionActive) {
        throw "A session is already active: $script:SessionId"
    }
    New-ToolDirectory
    $script:SessionId = Get-Date -Format 'yyyyMMdd_HHmmss'
    $script:SessionStart = Get-Date
    $script:SessionSeenProcess = $false
    $script:SessionActive = $true
    $sessionDir = Join-Path $script:Config.SessionRoot "FH6_Session_$script:SessionId"
    New-Item -ItemType Directory -Path $sessionDir -Force | Out-Null
    $script:SessionBeforeSnapshot = New-StateSnapshot -Label "session_${script:SessionId}_before"
    Copy-Item -LiteralPath $script:SessionBeforeSnapshot.Json -Destination (Join-Path $sessionDir 'before.json') -Force
    Copy-Item -LiteralPath $script:SessionBeforeSnapshot.Text -Destination (Join-Path $sessionDir 'before.txt') -Force
    (Get-PreflightText) | Set-Content -LiteralPath (Join-Path $sessionDir 'preflight.txt') -Encoding UTF8
    Start-Process "steam://run/$($script:Config.AppId)"
    Add-Log "Session $script:SessionId started and FH6 launch requested."
    return $sessionDir
}

function Complete-FH6LaunchSession {
    param([string]$Reason = 'manual')
    if (-not $script:SessionActive -or -not $script:SessionId) {
        throw 'No active FH6 launch session.'
    }
    $sessionDir = Join-Path $script:Config.SessionRoot "FH6_Session_$script:SessionId"
    New-Item -ItemType Directory -Path $sessionDir -Force | Out-Null
    $after = New-StateSnapshot -Label "session_${script:SessionId}_after_$Reason"
    Copy-Item -LiteralPath $after.Json -Destination (Join-Path $sessionDir 'after.json') -Force
    Copy-Item -LiteralPath $after.Text -Destination (Join-Path $sessionDir 'after.txt') -Force
    (Compare-LatestStateSnapshots) | Set-Content -LiteralPath (Join-Path $sessionDir 'snapshot-diff.txt') -Encoding UTF8
    (Get-CrashCorrelationSummary -Minutes 10) | Set-Content -LiteralPath (Join-Path $sessionDir 'latest-crash-correlation.txt') -Encoding UTF8
    (Get-ExpertRecommendationSummary) | Set-Content -LiteralPath (Join-Path $sessionDir 'expert-recommendations.txt') -Encoding UTF8
    (Get-EventTimelineSummary) | Set-Content -LiteralPath (Join-Path $sessionDir 'event-timeline.txt') -Encoding UTF8
    [pscustomobject]@{
        SessionId   = $script:SessionId
        StartedAt   = $script:SessionStart
        FinishedAt  = Get-Date
        Reason      = $Reason
        SawProcess  = $script:SessionSeenProcess
        SessionPath = $sessionDir
    } | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $sessionDir 'session.json') -Encoding UTF8
    Add-Log "Session $script:SessionId finished. Reason=$Reason Path=$sessionDir"
    $script:SessionActive = $false
    $script:SessionId = $null
    $script:SessionStart = $null
    $script:SessionBeforeSnapshot = $null
    $script:SessionSeenProcess = $false
    return $sessionDir
}

function Invoke-MonitorCleanup {
    try {
        $script:MonitorRunCount++
        $categories = if ($cmbMonitorMode.SelectedItem -eq 'Saves + cache') { @('Save','Cache/Settings') } else { @('Save') }
        $records = @(Get-FH6Inventory | Where-Object { $_.Exists -and $_.Cleanable -and ($categories -contains $_.Category) })
        if (@(Get-FH6Process).Count -gt 0 -and -not $chkStopGame.Checked) {
            $script:MonitorLastAction = 'Skipped: FH6 running'
            Add-Log "Monitor tick #$($script:MonitorRunCount): skipped because FH6 is running."
            return
        }
        if ($records.Count -eq 0) {
            $script:MonitorLastAction = 'Nothing found'
            Add-Log "Monitor tick #$($script:MonitorRunCount): nothing found."
            return
        }
        Add-Log "Monitor tick #$($script:MonitorRunCount): cleaning $($records.Count) item(s)."
        Invoke-Preflight -StopGame $chkStopGame.Checked -Log ${function:Add-Log} | Out-Null
        if ($chkBackup.Checked -and -not $chkDryRun.Checked) { Backup-FH6Targets -Records $records -Log ${function:Add-Log} | Out-Null }
        Remove-FH6Targets -Records $records -DryRun $chkDryRun.Checked -Log ${function:Add-Log}
        $script:MonitorLastAction = "Cleaned $($records.Count)"
        Refresh-SaveInventory
    }
    catch {
        $script:MonitorLastAction = "Error: $($_.Exception.Message)"
        Add-Log "Monitor error: $($_.Exception.Message)"
    }
    finally {
        $lblMonitorStatus.Text = "Ticks: $($script:MonitorRunCount). Last: $script:MonitorLastAction"
    }
}

$monitorTimer = New-Object System.Windows.Forms.Timer
$monitorTimer.Interval = [int]$numMonitorSec.Value * 1000
$monitorTimer.Add_Tick({
    if (-not $script:MonitorActive) { return }
    $monitorTimer.Stop()
    try { Invoke-MonitorCleanup } finally {
        $monitorTimer.Interval = [int]$numMonitorSec.Value * 1000
        if ($script:MonitorActive) { $monitorTimer.Start() }
    }
})

$sessionTimer = New-Object System.Windows.Forms.Timer
$sessionTimer.Interval = 5000
$sessionTimer.Add_Tick({
    if (-not $script:SessionActive) { return }
    try {
        $running = @(Get-FH6Process).Count -gt 0
        if ($running) {
            $script:SessionSeenProcess = $true
            return
        }
        $elapsed = if ($script:SessionStart) { ((Get-Date) - $script:SessionStart).TotalSeconds } else { 0 }
        if ($script:SessionSeenProcess -and -not $running) {
            $sessionDir = Complete-FH6LaunchSession -Reason 'process-ended'
            $txtPreflight.Text = "Session auto-finished after FH6 process ended.`r`n$sessionDir`r`n`r`n" + (Get-PreflightText)
        }
        elseif ($elapsed -gt 900) {
            $sessionDir = Complete-FH6LaunchSession -Reason 'timeout'
            $txtPreflight.Text = "Session auto-finished after 15 minute timeout.`r`n$sessionDir`r`n`r`n" + (Get-PreflightText)
        }
    }
    catch {
        Add-Log "Session timer warning: $($_.Exception.Message)"
    }
})

$telemetryTimer = New-Object System.Windows.Forms.Timer
$telemetryTimer.Interval = 100
$telemetryTimer.Add_Tick({
    if (-not $script:UdpClient) { return }
    try {
        while ($script:UdpClient -and $script:UdpClient.Available -gt 0) {
            $remote = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Any, 0)
            $bytes = $script:UdpClient.Receive([ref]$remote)
            $packet = Convert-BytesToTelemetryPacket -Bytes $bytes
            if (-not $packet) { continue }
            $script:TelemetryPacketCount++
            $script:TelemetryLastPacket = $packet
            if ($chkTelemCsv.Checked) { Write-TelemetryCsv -Packet $packet }
            $txtTelemetry.Text = @"
Packets: $script:TelemetryPacketCount
Last packet: $($packet.ReceivedAt)
Race on: $($packet.IsRaceOn)   Timestamp: $($packet.TimestampMS)

Speed: {0:N1} mph     RPM: {1:N0} / {2:N0}     Gear: {3}
Inputs: Accel={4} Brake={5} Clutch={6} HandBrake={7} Steer={8}

CarOrdinal: {9}   Class: {10}   PI: {11}   Drivetrain: {12}   Cylinders: {13}
Boost: {14:N2} psi   Fuel: {15:P1}

Lap: {16}   Position: {17}   Best: {18:N3}s   Last: {19:N3}s   Current: {20:N3}s   RaceTime: {21:N3}s

Tire slip ratio FL/FR/RL/RR: {22:N3} / {23:N3} / {24:N3} / {25:N3}
Tire temp FL/FR/RL/RR: {26:N1} / {27:N1} / {28:N1} / {29:N1}

World position: X={30:N2} Y={31:N2} Z={32:N2}
Velocity vector: X={33:N2} Y={34:N2} Z={35:N2}
Yaw/Pitch/Roll: {36:N3} / {37:N3} / {38:N3}
"@ -f $packet.SpeedMph, $packet.CurrentEngineRpm, $packet.EngineMaxRpm, $packet.Gear,
    $packet.Accel, $packet.Brake, $packet.Clutch, $packet.HandBrake, $packet.Steer,
    $packet.CarOrdinal, $packet.CarClass, $packet.PI, $packet.DrivetrainType, $packet.NumCylinders,
    $packet.BoostPsi, $packet.Fuel, $packet.LapNumber, $packet.RacePosition, $packet.BestLap, $packet.LastLap, $packet.CurrentLap, $packet.RaceTime,
    $packet.TireSlipFL, $packet.TireSlipFR, $packet.TireSlipRL, $packet.TireSlipRR,
    $packet.TireTempFL, $packet.TireTempFR, $packet.TireTempRL, $packet.TireTempRR,
    $packet.PositionX, $packet.PositionY, $packet.PositionZ,
    $packet.VelocityX, $packet.VelocityY, $packet.VelocityZ,
    $packet.Yaw, $packet.Pitch, $packet.Roll
        }
    }
    catch {
        Add-Log "Telemetry read error: $($_.Exception.Message)"
    }
})

$btnHealthScan.Add_Click({ Refresh-Health })
$btnHealthReport.Add_Click({
    $path = Export-FH6Report -Records @(Get-FH6Inventory)
    Add-Log "Report exported: $path"
    [System.Windows.Forms.MessageBox]::Show("Report exported:`n$path", 'Report exported', 'OK', 'Information') | Out-Null
})
$btnHealthSupport.Add_Click({
    $zip = New-SupportPackage -Log ${function:Add-Log}
    [System.Windows.Forms.MessageBox]::Show("Support package written:`n$zip", 'Support package', 'OK', 'Information') | Out-Null
})
$btnOpenLogs.Add_Click({ Start-Process -FilePath $script:Config.LogRoot })
$btnShowConflicts.Add_Click({ Show-TextWindow -Title 'Conflict Process Scan' -Text (Get-ConflictSummary) })
$btnSteamLogs.Add_Click({ Show-TextWindow -Title 'Steam FH6 Log Matches' -Text (Get-SteamLogSummary) })
$btnServiceDetails.Add_Click({
    $text = "Xbox/Gaming Services`r`n====================`r`n" + ((Get-XboxServiceRows | Format-Table -AutoSize | Out-String).Trim())
    Show-TextWindow -Title 'Xbox and Gaming Services' -Text $text
})
$btnRuntimeDetails.Add_Click({
    $mf = Get-MediaFoundationStatus
    $text = @(
        'Runtime Details',
        '===============',
        '',
        'Media Foundation:',
        "$($mf.Status): $($mf.Detail)",
        '',
        'Visual C++ Redistributables:',
        ((Get-VisualCRedistRows | Format-Table -AutoSize | Out-String).Trim())
    ) -join [Environment]::NewLine
    Show-TextWindow -Title 'Runtime Details' -Text $text
})
$btnRunbook.Add_Click({ Show-TextWindow -Title 'Expert Recommendation Runbook' -Text (Get-ExpertRecommendationSummary) })
$btnStartup.Add_Click({
    $text = "Startup and Logon Inventory`r`n===========================`r`n" + ((Get-StartupProgramRows | Format-Table -AutoSize | Out-String).Trim())
    Show-TextWindow -Title 'Startup Inventory' -Text $text
})
$btnPlatformAudit.Add_Click({
    $text = @(
        'Platform Audit',
        '==============',
        '',
        'Windows Gaming Settings:',
        ((Get-WindowsGamingSettingRows | Format-Table -AutoSize | Out-String).Trim()),
        '',
        'Power and Thermal:',
        ((Get-PowerThermalRows | Format-Table -AutoSize | Out-String).Trim()),
        '',
        'Xbox App Packages:',
        ((Get-XboxAppPackageRows | Format-Table -AutoSize | Out-String).Trim())
    ) -join [Environment]::NewLine
    Show-TextWindow -Title 'Platform Audit' -Text $text
})
$btnPermissionAudit.Add_Click({
    $text = "Path Permission Audit`r`n=====================`r`n" + ((Get-PathPermissionRows | Format-Table -AutoSize | Out-String).Trim())
    Show-TextWindow -Title 'Path Permission Audit' -Text $text
})
$btnBackupAudit.Add_Click({
    $text = "Backup Integrity Audit`r`n======================`r`n" + ((Get-BackupIntegrityRows | Format-Table -AutoSize | Out-String).Trim())
    Show-TextWindow -Title 'Backup Integrity Audit' -Text $text
})
$btnReliability.Add_Click({
    $text = "Reliability Monitor Records`r`n===========================`r`n" + ((Get-ReliabilityRecordRows | Format-Table -AutoSize | Out-String).Trim())
    Show-TextWindow -Title 'Reliability Monitor Records' -Text $text
})
$btnDisplayAudit.Add_Click({
    $text = "Display and GPU Topology`r`n========================`r`n" + ((Get-DisplayTopologyRows | Format-Table -AutoSize | Out-String).Trim())
    Show-TextWindow -Title 'Display and GPU Topology' -Text $text
})
$btnCompatAudit.Add_Click({
    $text = @(
        'Compatibility and GPU Preference Audit',
        '======================================',
        '',
        'Compatibility Layers:',
        ((Get-AppCompatLayerRows | Format-Table -AutoSize | Out-String).Trim()),
        '',
        'Graphics Preferences:',
        ((Get-GraphicsPreferenceRows | Format-Table -AutoSize | Out-String).Trim())
    ) -join [Environment]::NewLine
    Show-TextWindow -Title 'Compatibility and GPU Preferences' -Text $text
})
$btnSecurityAudit.Add_Click({
    $text = "Security Product Inventory`r`n==========================`r`n" + ((Get-SecurityProductRows | Format-Table -AutoSize | Out-String).Trim())
    Show-TextWindow -Title 'Security Product Inventory' -Text $text
})

$btnSaveScan.Add_Click({ Refresh-SaveInventory })
$btnSelectSaves.Add_Click({ Select-SaveCategories -Categories @('Save') })
$btnSelectDeep.Add_Click({ Select-SaveCategories -Categories @('Save','Cache/Settings') })
$btnClearSel.Add_Click({ foreach ($row in $listSaves.Items) { $row.Checked = $false } })
$btnBackup.Add_Click({ Backup-FH6Targets -Records @(Get-SelectedSaveRecords) -Log ${function:Add-Log} | Out-Null })
$btnRename.Add_Click({ Invoke-SaveAction -Action 'Rename' -Records @(Get-SelectedSaveRecords) })
$btnDelete.Add_Click({ Invoke-SaveAction -Action 'Delete' -Records @(Get-SelectedSaveRecords) })
$btnFresh.Add_Click({ Select-SaveCategories -Categories @('Save'); Invoke-SaveAction -Action 'Delete' -Records @(Get-SelectedSaveRecords) })
$btnDeepFresh.Add_Click({ Select-SaveCategories -Categories @('Save','Cache/Settings'); Invoke-SaveAction -Action 'Delete' -Records @(Get-SelectedSaveRecords) })
$btnRestore.Add_Click({
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = 'Choose FH6 Companion Doctor backup zip'
    $dialog.InitialDirectory = $script:Config.BackupRoot
    $dialog.Filter = 'FH6 backups (*.zip)|*.zip|All files (*.*)|*.*'
    if ($dialog.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { return }
    try {
        Invoke-Preflight -StopGame $chkStopGame.Checked -Log ${function:Add-Log} | Out-Null
        Restore-FH6Backup -ZipPath $dialog.FileName -DryRun $chkDryRun.Checked -Log ${function:Add-Log}
        Refresh-SaveInventory
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Restore failed', 'OK', 'Error') | Out-Null
        Add-Log "Restore failed: $($_.Exception.Message)"
    }
})
$btnMonitor.Add_Click({
    if (-not $script:MonitorActive) {
        $script:MonitorActive = $true
        $script:MonitorRunCount = 0
        $script:MonitorLastAction = 'Started'
        $btnMonitor.Text = 'Stop Monitor'
        $lblMonitorStatus.Text = "Running every $([int]$numMonitorSec.Value)s"
        Add-Log "Monitor started: $($cmbMonitorMode.SelectedItem), interval=$([int]$numMonitorSec.Value)s"
        $monitorTimer.Interval = [int]$numMonitorSec.Value * 1000
        $monitorTimer.Start()
    }
    else {
        $script:MonitorActive = $false
        $monitorTimer.Stop()
        $btnMonitor.Text = 'Start Monitor'
        $lblMonitorStatus.Text = "Stopped. Ticks=$($script:MonitorRunCount). Last=$script:MonitorLastAction"
        Add-Log "Monitor stopped."
    }
})

$btnCrashRefresh.Add_Click({ Refresh-Crashes })
$btnCrashSummary.Add_Click({ Show-TextWindow -Title 'Crash Summary' -Text (Get-CrashSummary) })
$btnCrashAnalysis.Add_Click({ Show-TextWindow -Title 'Crash Signature Analysis' -Text (Get-CrashSignatureAnalysis) })
$btnWerReports.Add_Click({
    $text = "WER Reports`r`n===========`r`n" + ((Get-WERReportRows | Format-Table -AutoSize | Out-String).Trim())
    Show-TextWindow -Title 'FH6 WER Reports' -Text $text
})
$btnTimeline.Add_Click({ Show-TextWindow -Title 'FH6 Event Timeline' -Text (Get-EventTimelineSummary) })
$btnCorrelation.Add_Click({ Show-TextWindow -Title 'Latest Crash Correlation' -Text (Get-CrashCorrelationSummary -Minutes 10) })
$btnClearCrashReports.Add_Click({
    Refresh-SaveInventory
    $records = @(Get-FH6Inventory | Where-Object { $_.Category -eq 'Crash Report' })
    Invoke-SaveAction -Action 'Delete' -Records $records
    Refresh-Crashes
})

$btnTelemStart.Add_Click({
    try {
        if ($script:UdpClient) { $script:UdpClient.Close(); $script:UdpClient = $null }
        $port = [int]$numPort.Value
        $script:UdpClient = New-Object System.Net.Sockets.UdpClient($port)
        $script:TelemetryPacketCount = 0
        $script:TelemetryCsvPath = if ($chkTelemCsv.Checked) { Join-Path $script:Config.TelemetryRoot ("FH6_DataOut_{0}_port{1}.csv" -f (Get-Date -Format 'yyyyMMdd_HHmmss'), $port) } else { $null }
        $txtTelemetry.Text = "Listening for FH6 Data Out UDP on 127.0.0.1:$port...`r`nEnable Data Out in-game and start driving."
        $telemetryTimer.Start()
        Add-Log "Telemetry listener started on UDP port $port. CSV=$script:TelemetryCsvPath"
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Telemetry start failed', 'OK', 'Error') | Out-Null
        Add-Log "Telemetry start failed: $($_.Exception.Message)"
    }
})
$btnTelemStop.Add_Click({
    $telemetryTimer.Stop()
    if ($script:UdpClient) { $script:UdpClient.Close(); $script:UdpClient = $null }
    Add-Log 'Telemetry listener stopped.'
})
$btnOpenTelemetry.Add_Click({ Start-Process -FilePath $script:Config.TelemetryRoot })
$btnTelemPreflight.Add_Click({ Show-TextWindow -Title 'Telemetry Port Preflight' -Text (Get-TelemetryPreflightSummary -Port ([int]$numPort.Value)) })

$btnDevicesRefresh.Add_Click({ Refresh-Devices })
$btnDeviceAdvice.Add_Click({
    $text = @"
FH6 wheel/device reminders:

- Update wheel drivers and firmware before testing.
- Avoid USB hubs for wheels; use a direct USB 3.0 port where possible.
- If force feedback is missing, the wheelbase may not be Device 1 in-game.
- Temporarily unplug extra controllers, shifters, pedals, or adapters to test.
- Steam Controller is listed in FH6 known issues as potentially crash-prone in some circumstances.
- For multiple USB devices, create/check a custom wheel profile in-game.
"@
    Show-TextWindow -Title 'Wheel and Device Advice' -Text $text
})
$btnDriverInventory.Add_Click({
    $text = "Driver Inventory`r`n================`r`n" + ((Get-DriverInventoryRows | Format-Table -AutoSize | Out-String).Trim())
    Show-TextWindow -Title 'Driver Inventory' -Text $text
})

$btnPreflight.Add_Click({ $txtPreflight.Text = Get-PreflightText; Add-Log 'Preflight scan complete.' })
$btnLaunchSteam.Add_Click({ Start-Process "steam://run/$($script:Config.AppId)"; Add-Log 'Launch requested through Steam URI.' })
$btnPreflightLaunch.Add_Click({
    $txtPreflight.Text = Get-PreflightText
    $snap = New-StateSnapshot -Label 'preflight-launch'
    Add-Log "Preflight snapshot: $($snap.Text)"
    Start-Process "steam://run/$($script:Config.AppId)"
    Add-Log 'Preflight complete, launch requested through Steam URI.'
})
$btnSnapshotBefore.Add_Click({
    $snap = New-StateSnapshot -Label 'manual-launch-tab'
    $txtPreflight.Text = "Snapshot written:`r`n$($snap.Text)`r`n$($snap.Json)`r`n`r`n" + (Get-PreflightText)
    Add-Log "State snapshot written: $($snap.Text)"
})
$btnSteamCloudSteps.Add_Click({
    $msg = @"
Steam Cloud must be off before a clean local-save test:

1. Open Steam Library.
2. Right-click Forza Horizon 6.
3. Choose Properties.
4. Open General.
5. Turn off Steam Cloud sync for Forza Horizon 6.

Launch once with Steam Cloud off. If FH6 creates clean local data and loads, exit normally before deciding whether to re-enable cloud sync.
"@
    [System.Windows.Forms.MessageBox]::Show($msg, 'Steam Cloud steps', 'OK', 'Information') | Out-Null
})
$btnOpenSteamInstall.Add_Click({
    $install = @(Get-SteamInstallInfo | Where-Object { $_.ExeExists } | Select-Object -First 1)
    if ($install.Count -gt 0) { Start-Process -FilePath $install[0].InstallDir }
    else { [System.Windows.Forms.MessageBox]::Show('Steam FH6 install was not detected.', 'Install folder', 'OK', 'Information') | Out-Null }
})
$btnInstallAudit.Add_Click({
    $text = "Read-only Install Audit`r`n=======================`r`n" + ((Get-InstallAuditRows | Format-Table -AutoSize | Out-String).Trim())
    Show-TextWindow -Title 'Read-only Install Audit' -Text $text
})
$btnSessionLaunch.Add_Click({
    try {
        $answer = [System.Windows.Forms.MessageBox]::Show(
            "Start a tracked FH6 launch session?`n`nThe tool will create a before snapshot, request Steam launch, then watch for FH6 to exit and capture an after snapshot/session report.",
            'Start tracked session',
            'OKCancel',
            'Information'
        )
        if ($answer -ne [System.Windows.Forms.DialogResult]::OK) { return }
        $dir = Start-FH6LaunchSession
        $txtPreflight.Text = "Tracked session started:`r`n$dir`r`n`r`n" + (Get-PreflightText)
        $sessionTimer.Start()
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Session failed', 'OK', 'Error') | Out-Null
        Add-Log "Session launch failed: $($_.Exception.Message)"
    }
})
$btnSessionFinish.Add_Click({
    try {
        $dir = Complete-FH6LaunchSession -Reason 'manual'
        $txtPreflight.Text = "Tracked session finished:`r`n$dir`r`n`r`n" + (Get-PreflightText)
        $sessionTimer.Stop()
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Finish session failed', 'OK', 'Error') | Out-Null
        Add-Log "Finish session failed: $($_.Exception.Message)"
    }
})

$btnExportReport.Add_Click({
    $path = Export-FH6Report -Records @(Get-FH6Inventory)
    $txtReports.Text = "Report exported:`r`n$path"
    Add-Log "Report exported: $path"
})
$btnSupportPackage.Add_Click({
    $zip = New-SupportPackage -Log ${function:Add-Log}
    $txtReports.Text = "Support package written:`r`n$zip"
})
$btnStateSnapshot.Add_Click({
    $snap = New-StateSnapshot -Label 'manual'
    $txtReports.Text = "State snapshot written:`r`n$($snap.Text)`r`n$($snap.Json)"
    Add-Log "State snapshot written: $($snap.Text)"
})
$btnSnapshotDiff.Add_Click({
    $diff = Compare-LatestStateSnapshots
    $txtReports.Text = $diff
    Show-TextWindow -Title 'Latest State Snapshot Diff' -Text $diff
})
$btnRedactedReport.Add_Click({
    $raw = @(
        'FH6 Companion Doctor Redacted Summary',
        '=====================================',
        '',
        '== Status ==',
        (Get-StatusSummary),
        '',
        '== Expert Recommendations ==',
        (Get-ExpertRecommendationSummary),
        '',
        '== Crash Analysis ==',
        (Get-CrashSignatureAnalysis),
        '',
        '== Event Timeline ==',
        (Get-EventTimelineSummary)
    ) -join [Environment]::NewLine
    $redacted = ConvertTo-RedactedText -Text $raw
    $path = Join-Path $script:Config.ReportRoot ("FH6_CompanionDoctor_RedactedSummary_{0}.txt" -f (Get-Date -Format 'yyyyMMdd_HHmmss'))
    $redacted | Set-Content -LiteralPath $path -Encoding UTF8
    $txtReports.Text = "Redacted summary written:`r`n$path"
    Add-Log "Redacted summary written: $path"
    Show-TextWindow -Title 'Redacted Summary' -Text $redacted
})
$btnOpenReports.Add_Click({ Start-Process -FilePath $script:Config.ReportRoot })
$btnOpenPackages.Add_Click({ Start-Process -FilePath $script:Config.PackageRoot })
$btnOpenSnapshots.Add_Click({ Start-Process -FilePath $script:Config.SnapshotRoot })
$btnOpenSessions.Add_Click({ Start-Process -FilePath $script:Config.SessionRoot })
$btnSelfTest.Add_Click({
    $rows = @(Invoke-CompanionSelfTest)
    $text = "FH6 Companion Doctor Self-Test`r`n=============================`r`n" + (($rows | Format-Table -AutoSize | Out-String).Trim())
    $txtReports.Text = $text
    Show-TextWindow -Title 'Self-Test' -Text $text
})
$btnSafetyAudit.Add_Click({
    $rows = @(Get-ToolSafetyAuditRows)
    $text = "FH6 Companion Doctor Safety Audit`r`n=================================`r`n" + (($rows | Format-Table -AutoSize | Out-String).Trim())
    $txtReports.Text = $text
    Show-TextWindow -Title 'Safety Audit' -Text $text
})
$btnManifest.Add_Click({
    $path = Write-ToolManifest
    $txtReports.Text = "Manifest written:`r`n$path"
    Add-Log "Manifest written: $path"
    Start-Process -FilePath (Split-Path -Path $path -Parent)
})
$btnOfficialRefs.Add_Click({
    $text = "Official References`r`n===================`r`n" + ((Get-OfficialReferenceRows | Format-Table -AutoSize | Out-String).Trim())
    $txtReports.Text = $text
    Show-TextWindow -Title 'Official References' -Text $text
})
$btnPortableBundle.Add_Click({
    try {
        $zip = New-PortableToolBundle -Log ${function:Add-Log}
        $txtReports.Text = "Portable bundle written:`r`n$zip"
        [System.Windows.Forms.MessageBox]::Show("Portable bundle written:`n$zip", 'Portable Bundle', 'OK', 'Information') | Out-Null
    }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Portable bundle failed', 'OK', 'Error') | Out-Null
        Add-Log "Portable bundle failed: $($_.Exception.Message)"
    }
})
$btnOpenBundles.Add_Click({ Start-Process -FilePath $script:Config.BundleRoot })

$form.Add_FormClosing({
    $script:MonitorActive = $false
    $monitorTimer.Stop()
    $sessionTimer.Stop()
    $telemetryTimer.Stop()
    if ($script:UdpClient) { $script:UdpClient.Close(); $script:UdpClient = $null }
    try { Save-CompanionSettingsFromUi } catch { Add-Log "Settings save warning: $($_.Exception.Message)" }
    Add-Log 'FH6 Companion Doctor closing.'
})

Apply-CompanionSettingsToUi
Refresh-Health
Refresh-SaveInventory
Refresh-Crashes
Refresh-Devices
$txtPreflight.Text = Get-PreflightText
$txtReports.Text = "Reports: $($script:Config.ReportRoot)`r`nSupport packages: $($script:Config.PackageRoot)`r`nBackups: $($script:Config.BackupRoot)"
Add-Log 'FH6 Companion Doctor v4.0 ready.'

[void][System.Windows.Forms.Application]::Run($form)
