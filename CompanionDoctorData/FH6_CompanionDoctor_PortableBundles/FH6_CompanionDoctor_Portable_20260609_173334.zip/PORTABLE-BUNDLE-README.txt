﻿FH6 Companion Doctor Portable Bundle
Generated: 06/09/2026 17:36:28

Run:
  Run-FH6-CompanionDoctor.cmd

Safety:
  This external tool does not modify FH6 game install files, does not inject into
  the game, does not read/write game memory, and does not automate gameplay.

Included:
  - Tool scripts and launcher
  - README
  - Manifest with SHA256 hashes
  - Official references
  - Safety audit
  - Self-test output
