﻿FH6 Companion Doctor Portable Bundle
Generated: 06/08/2026 21:40:12

Run:
  Run-FH6-CompanionDoctor.cmd

Safety:
  This external tool does not modify FH6 game install files, does not inject into
  the game, does not read/write game memory, and does not automate gameplay.

Included:
  - Tool scripts and launcher
  - README
  - Manifest with SHA256 hashes
  - Official references
  - Safety audit
  - Self-test output
